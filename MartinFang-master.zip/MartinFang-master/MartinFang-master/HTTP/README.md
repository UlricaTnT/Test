# 作业

目录
- user_login
- user_server
- readme

做完这次的作业我有了很大的提升，对http协议都有了一个比较清晰的了解，虽然使用还是十分的不灵活，但是大体上能够完成一些简单的http协议的传输和一些头部信息的解析

下面我简单讲一下我自己的作业
1. 建立路由表
    - 定义特性

            /// <summary>
            /// 定义一个自定义的属性，主要为了路由表的创建
            /// </summary>
            [AttributeUsageAttribute(AttributeTargets.Class|AttributeTargets.Property,Inherited =true)]
            class urlAttribute:Attribute
             {
                public string url;
                public string classname;

                public string getname()
                {
                    return classname;
                }
                public string geturl()
                {
                    return url;
                }
            }
    - 将定义的资源类绑定特性
    - 程序运行开始前生成路由表加载路由表

            #region 设置全局变量路由表
            //加载当前程序集
            Assembly assm = Assembly.GetExecutingAssembly();
            Type[] a = assm.GetTypes();
            //遍历所有的类，查找属性加入路由表
            foreach (Type ta in a)
            {
                if (urlAttribute.IsDefined(ta, typeof(urlAttribute)))
                {
                    Attribute[] o = urlAttribute.GetCustomAttributes(ta);
                    foreach (var attr in o)
                    {
                        urlAttribute attrs = (urlAttribute)attr;
                        routclass.rout.Add(attrs.geturl(), attrs.getname());
                    }
                }
            }
            #endregion 

2. 建立接口依赖关系
    - 建立接口

            /// <summary>
            /// 申明一个借口，主要作用是为了实例化对象后的方法调用
            /// </summary>
            public interface IROUT
            {
                HTTPResponse Get(HttpReaquest request);

                HTTPResponse Post(HttpReaquest request);

                HTTPResponse Put(HttpReaquest request);

                HTTPResponse Delete(HttpReaquest request);

                 HTTPResponse Options(Dictionary<string, string> a);
            }
    - 将对象转换成接口调用相对应的方法

             //将对象转换为接口类型，方法的调用
                IROUT irout = (IROUT)assm.CreateInstance(routclass.rout[request[0].url]);

                HTTPResponse response = new HTTPResponse();
3. 解析http请求做出相对应的处理

         if (request[0].method == "POST")
            {
                //调用方法
                response = irout.Post(request[0]);
                //重置当前会话超时时间
               session.Session[request[0].header["Cookie"]] DateTime.Now.AddMinutes(3);

           }
            if (request[0].method == "GET")
            {
                response = irout.Get(request[0]);
                session.Session[request[0].header["Cookie"]] = DateTime.Now.AddMinutes(3);

                    }
            if (request[0].method == "PUT")
            {
                response = irout.Put(request[0]);
                session.Session[request[0].header["Cookie"]] = DateTime.Now.AddMinutes(3);

           }
            if (request[0].method == "DELETE")
            {
                response = irout.Delete(request[0]);
                session.Session[request[0].header["Cookie"]] = DateTime.Now.AddMinutes(3);

            }


---


我在自己写的客户端加了一个全局的会话表，当你的客户端在一定时间对服务器没有请求的时候当作离线，然后当你重新请求的时候需要重新登陆。

        /// <summary>
        /// 全局会话表，当前用户的会话时间是否过期
        /// </summary>
        public static class session
        {
         public static Dictionary<string,DateTime> Session = new     Dictionary<string, DateTime>();
        }
         /// <summary>
        /// 循环监听全局会话表，如果长时间不操作客户端，需要重新登录
        /// </summary>
        public void destroysession()
        {
            Thread destory = new Thread(() =>
              {
                  while (true)
                  {
                      if (session.Session.Count == 0)
                      {
                          continue;
                      }
                      else
                      {
                          List<string> deletestring = new List<string>();
                          foreach (KeyValuePair<string, DateTime> cs in session.Session)
                          {
                              if (cs.Value < DateTime.Now)
                              {
                                  deletestring.Add(cs.Key);
                              }
                          }
                          foreach (string de in deletestring)
                          {
                              session.Session.Remove(de);
                          }
                      }
                      Thread.Sleep(100);
                  }
                  
              });
            destory.Start();
        }

判断

       //判断当前用户的会话时间是否超时，或还没有建立过连接
        if (!request[0].header.ContainsKey("Cookie") || !session.Session.ContainsKey(request[0].header["Cookie"]))
                {
                    response.version = "HTTP/1.1";
                    response.statecode = "402 Expired";
                    string s = Guid.NewGuid().ToString();
                    response.header.Add("Date", DateTime.Now.ToString());
                    session.Session[s] = DateTime.Now.AddMinutes(3);
                    response.header.Add("Cookie", s);

                }

---
我加了一个静态文件方法，在请求过来的时候先判断是否为静态文件，如果为静态文件则直接将静态文件读取后打包

         public static class StaticFile
        {
            public static bool FindFile(string url)
            {
                string path1 = url.Replace('/', '\\');
                string path = System.Environment.CurrentDirectory + path1;
                return File.Exists(path);
            }
        public static void FindStaticFile(Socket client, string url)
        {
            string path1 = url.Replace('/', '\\');
            string path = System.Environment.CurrentDirectory + path1;
            string data = File.ReadAllText(path);
            string message = "HTTP / 1.1 200 OK \r\n" +
                "Content-Length:" + data.Length + "\r\n" +
                "Content-type:text/html" + "\r\n" +
                "Date:" + DateTime.Now.ToUniversalTime().ToString() + "\r\n"
                + "\r\n" +
                data;
            client.Send(Encoding.Default.GetBytes(message));
        }
    }

        //判断方法
         if (StaticFile.FindFile(http.url))
                {
                    StaticFile.FindStaticFile(client, http.url);
                }
                else
                {
                    clientpool[client].isnull = false;
                    clientpool[client].request.Add(http);
                }

上面的值返回了一个静态文件就是1.html。

<<<<<<< HEAD
![](picture/Capture.PNG)
=======
![](../../blob/master/HTTP/picture/Capture.PNG)
>>>>>>> 08c8eafd1098548871a9a7195e374c0c542234bb

---
做了一个accept的简单的映射关系

        /// <summary>
        /// 将对象转换为客户端需要的类型
        /// </summary>
        /// <param name="a">需要转换的对象</param>
        /// <param name="type">客户端需要的类型</param>
        /// <returns></returns>
        public static List<string> analy(object[] a, string type)
        {
            bool isanaly = false;
            List<string> return_value = new List<string>();

            foreach (var s in type.Split(','))
            {
                if (s == "text/json")
                {
                    string data = "";
                    data += JsonConvert.SerializeObject(a);
                    return_value.Add(s);
                    return_value.Add(Encoding.Default.GetBytes(data).Length.ToString());
                    return_value.Add(data);
                     
                }
                if (s == " text/html")
                {
                    string data = "";
                    data += "<HTML><HEAD><TITLE>USER</TITLE><BODY>";
                    foreach (var ob in a)
                    {
                        data += "<p>" + ob + "</p>";
                        
                    }
                    data += "</BODY></HTML>";
                    return_value.Add(s);
                    return_value.Add(Encoding.Default.GetBytes(data).Length.ToString());
                    return_value.Add(data);
                }
            }
            if (!isanaly)
            {
                object ob = new { message = "error accept", hope = "text/json" };
                string data = JsonConvert.SerializeObject(ob);
                return_value.Add("text/json");
                return_value.Add(Encoding.Default.GetBytes(data).Length.ToString());
                return_value.Add(data);
                return_value.Add("203 error accept");
            }
            return return_value;
        }

效果

![](picture/Capture1.png)


代码还很粗糙，里面在浏览器中访问的代码都需要一些特殊的注释。
