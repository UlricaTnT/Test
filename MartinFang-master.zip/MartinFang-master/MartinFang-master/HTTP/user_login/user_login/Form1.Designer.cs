﻿namespace user_login
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_login = new System.Windows.Forms.Button();
            this.tbx_login_name = new System.Windows.Forms.TextBox();
            this.tbx_login_password = new System.Windows.Forms.TextBox();
            this.btn_reset = new System.Windows.Forms.Button();
            this.label_login_name = new System.Windows.Forms.Label();
            this.label_login_password = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(59, 179);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(75, 23);
            this.btn_login.TabIndex = 0;
            this.btn_login.Text = "登陆";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // tbx_login_name
            // 
            this.tbx_login_name.Location = new System.Drawing.Point(126, 58);
            this.tbx_login_name.Name = "tbx_login_name";
            this.tbx_login_name.Size = new System.Drawing.Size(163, 20);
            this.tbx_login_name.TabIndex = 1;
            // 
            // tbx_login_password
            // 
            this.tbx_login_password.Location = new System.Drawing.Point(126, 111);
            this.tbx_login_password.Name = "tbx_login_password";
            this.tbx_login_password.Size = new System.Drawing.Size(163, 20);
            this.tbx_login_password.TabIndex = 2;
            // 
            // btn_reset
            // 
            this.btn_reset.Location = new System.Drawing.Point(214, 179);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 23);
            this.btn_reset.TabIndex = 3;
            this.btn_reset.Text = "注册";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // label_login_name
            // 
            this.label_login_name.AutoSize = true;
            this.label_login_name.Location = new System.Drawing.Point(56, 61);
            this.label_login_name.Name = "label_login_name";
            this.label_login_name.Size = new System.Drawing.Size(43, 13);
            this.label_login_name.TabIndex = 4;
            this.label_login_name.Text = "登陆名";
            // 
            // label_login_password
            // 
            this.label_login_password.AutoSize = true;
            this.label_login_password.Location = new System.Drawing.Point(56, 114);
            this.label_login_password.Name = "label_login_password";
            this.label_login_password.Size = new System.Drawing.Size(55, 13);
            this.label_login_password.TabIndex = 5;
            this.label_login_password.Text = "登陆密码";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 241);
            this.Controls.Add(this.label_login_password);
            this.Controls.Add(this.label_login_name);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.tbx_login_password);
            this.Controls.Add(this.tbx_login_name);
            this.Controls.Add(this.btn_login);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.TextBox tbx_login_name;
        private System.Windows.Forms.TextBox tbx_login_password;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Label label_login_name;
        private System.Windows.Forms.Label label_login_password;
    }
}

