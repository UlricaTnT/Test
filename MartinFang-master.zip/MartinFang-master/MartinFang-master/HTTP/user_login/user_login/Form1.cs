﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Text.RegularExpressions;
using System.Configuration;


namespace user_login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        

        

        

        private void btn_login_Click(object sender, EventArgs e)
        {
            
            byte[] message = new byte[1024];

            #region//生成请求报文
            string data = "user_id:" + tbx_login_name.Text + ",user_password:" + tbx_login_password.Text;
            RequestHttp request = new RequestHttp("POST", "HTTP/1.1", "/user_login",data);
            byte[] sendmessage = Encoding.Default.GetBytes(request.Return_http());
            #endregion


            Program.socket.Send(sendmessage);

            int byt = Program.socket.Receive(message);

            string msg = Encoding.Default.GetString(message, 0, byt);
            HTTPResponse response = new HTTPResponse(msg);

            if (statecode.state_code(response) == "成功")
            {
                MessageBox.Show("欢迎你");
                client re = new client();
                re.Owner = this;
                re.Show();
                this.Hide();
            }
            else if (statecode.state_code(response) == "重新登录")
            {
                ConfigurationSettings.AppSettings.Set("Cookie", response.header["Cookie"]);
                btn_login_Click(this, e);

            }
            else
            {
                MessageBox.Show(statecode.state_code(response));
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            regis re = new regis();
            re.Owner = this;
            re.Show();
            this.Hide();
            
        }
    }
}
