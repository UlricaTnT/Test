﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace user_login
{
    public class HTTPResponse
    {
        public string version { get; set; }
        public string statecode { get; set; }
        public Dictionary<string, string> header = new Dictionary<string, string>();
        public string data;

        public HTTPResponse(string s)
        {
            Regex regex = new Regex("\r\n");
            string[] _data = regex.Split(s);
            Regex regexs = new Regex(" ");
            version = regexs.Split(_data[0],2)[0];
            statecode = regexs.Split(_data[0], 2)[1];
            for (int i = 1; i < _data.Length; i++)
            {
                if (_data[i] == "")
                    break;
                else
                {
                    Regex regexh = new Regex(":");
                    string[] par = regexh.Split(_data[i], 2);
                    header.Add(par[0], par[1]);
                }
            }
            data = _data[_data.Length - 1];
        }
    }
}
