﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Text;

namespace user_login
{
    public class RequestHttp
    {
        private string method;
        public string DATA;
        private string version;
        private string host;
        Dictionary<string, string> request = new Dictionary<string, string>();

        public RequestHttp(string _method, string _version,string _host, string _data=null)
        {
            string[] keys = ConfigurationManager.AppSettings.AllKeys;
            foreach (string key in keys)
            {
                if (ConfigurationManager.AppSettings.GetValues(key)[0] != "")
                {
                    request.Add(key, ConfigurationManager.AppSettings.GetValues(key)[0].ToString());
                }
            }
            DATA = _data;
            method = _method;
            host = _host;
            version = _version;

        }

        public string Return_http()
        {
            StringBuilder http_request = new StringBuilder();
            http_request.Append(method+" "+host+" "+version+"\r\n");
            foreach (var header in request)
            {
                http_request.Append(header.Key + ":" + header.Value+"\r\n");
            }
            if (DATA != "" || string.IsNullOrEmpty(DATA))
            {
                http_request.Append( "\r\n");
                http_request.Append(DATA+"\r\n");
            }

            return http_request.ToString();
        }
    }
}
