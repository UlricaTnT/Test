﻿namespace user_login
{
    partial class client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richbox_getname = new System.Windows.Forms.RichTextBox();
            this.btn_get_information = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textbox_delete = new System.Windows.Forms.TextBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.bnt_add_user = new System.Windows.Forms.Button();
            this.tbx_update_id = new System.Windows.Forms.TextBox();
            this.tbx_update_name = new System.Windows.Forms.TextBox();
            this.tbx_update_tel = new System.Windows.Forms.TextBox();
            this.tbx_update_bir = new System.Windows.Forms.TextBox();
            this.lab_update_id = new System.Windows.Forms.Label();
            this.lab_update_name = new System.Windows.Forms.Label();
            this.lab_update_tel = new System.Windows.Forms.Label();
            this.lab_update_birthday = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // richbox_getname
            // 
            this.richbox_getname.Location = new System.Drawing.Point(12, 12);
            this.richbox_getname.Name = "richbox_getname";
            this.richbox_getname.Size = new System.Drawing.Size(445, 569);
            this.richbox_getname.TabIndex = 0;
            this.richbox_getname.Text = "";
            // 
            // btn_get_information
            // 
            this.btn_get_information.Location = new System.Drawing.Point(711, 97);
            this.btn_get_information.Name = "btn_get_information";
            this.btn_get_information.Size = new System.Drawing.Size(76, 23);
            this.btn_get_information.TabIndex = 2;
            this.btn_get_information.Text = "搜索";
            this.btn_get_information.UseVisualStyleBackColor = true;
            this.btn_get_information.Click += new System.EventHandler(this.btn_get_information_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(548, 97);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(157, 20);
            this.textBox1.TabIndex = 3;
            // 
            // textbox_delete
            // 
            this.textbox_delete.Location = new System.Drawing.Point(548, 194);
            this.textbox_delete.Name = "textbox_delete";
            this.textbox_delete.Size = new System.Drawing.Size(155, 20);
            this.textbox_delete.TabIndex = 4;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(711, 192);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(78, 23);
            this.btn_delete.TabIndex = 5;
            this.btn_delete.Text = "删除用户";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(463, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "用户ID：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(463, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "用户ID：";
            // 
            // bnt_add_user
            // 
            this.bnt_add_user.Location = new System.Drawing.Point(649, 558);
            this.bnt_add_user.Name = "bnt_add_user";
            this.bnt_add_user.Size = new System.Drawing.Size(140, 23);
            this.bnt_add_user.TabIndex = 8;
            this.bnt_add_user.Text = "更新用户";
            this.bnt_add_user.UseVisualStyleBackColor = true;
            this.bnt_add_user.Click += new System.EventHandler(this.bnt_add_user_Click);
            // 
            // tbx_update_id
            // 
            this.tbx_update_id.Location = new System.Drawing.Point(583, 267);
            this.tbx_update_id.Name = "tbx_update_id";
            this.tbx_update_id.Size = new System.Drawing.Size(206, 20);
            this.tbx_update_id.TabIndex = 9;
            // 
            // tbx_update_name
            // 
            this.tbx_update_name.Location = new System.Drawing.Point(583, 349);
            this.tbx_update_name.Name = "tbx_update_name";
            this.tbx_update_name.Size = new System.Drawing.Size(206, 20);
            this.tbx_update_name.TabIndex = 10;
            // 
            // tbx_update_tel
            // 
            this.tbx_update_tel.Location = new System.Drawing.Point(583, 411);
            this.tbx_update_tel.Name = "tbx_update_tel";
            this.tbx_update_tel.Size = new System.Drawing.Size(206, 20);
            this.tbx_update_tel.TabIndex = 11;
            // 
            // tbx_update_bir
            // 
            this.tbx_update_bir.Location = new System.Drawing.Point(583, 469);
            this.tbx_update_bir.Name = "tbx_update_bir";
            this.tbx_update_bir.Size = new System.Drawing.Size(206, 20);
            this.tbx_update_bir.TabIndex = 12;
            // 
            // lab_update_id
            // 
            this.lab_update_id.AutoSize = true;
            this.lab_update_id.Location = new System.Drawing.Point(463, 274);
            this.lab_update_id.Name = "lab_update_id";
            this.lab_update_id.Size = new System.Drawing.Size(63, 13);
            this.lab_update_id.TabIndex = 13;
            this.lab_update_id.Text = "用   户ID：";
            // 
            // lab_update_name
            // 
            this.lab_update_name.AutoSize = true;
            this.lab_update_name.Location = new System.Drawing.Point(463, 356);
            this.lab_update_name.Name = "lab_update_name";
            this.lab_update_name.Size = new System.Drawing.Size(67, 13);
            this.lab_update_name.TabIndex = 14;
            this.lab_update_name.Text = "用户姓名：";
            // 
            // lab_update_tel
            // 
            this.lab_update_tel.AutoSize = true;
            this.lab_update_tel.Location = new System.Drawing.Point(463, 418);
            this.lab_update_tel.Name = "lab_update_tel";
            this.lab_update_tel.Size = new System.Drawing.Size(67, 13);
            this.lab_update_tel.TabIndex = 15;
            this.lab_update_tel.Text = "用户电话：";
            // 
            // lab_update_birthday
            // 
            this.lab_update_birthday.AutoSize = true;
            this.lab_update_birthday.Location = new System.Drawing.Point(463, 476);
            this.lab_update_birthday.Name = "lab_update_birthday";
            this.lab_update_birthday.Size = new System.Drawing.Size(67, 13);
            this.lab_update_birthday.TabIndex = 16;
            this.lab_update_birthday.Text = "用户生日：";
            // 
            // client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 608);
            this.Controls.Add(this.lab_update_birthday);
            this.Controls.Add(this.lab_update_tel);
            this.Controls.Add(this.lab_update_name);
            this.Controls.Add(this.lab_update_id);
            this.Controls.Add(this.tbx_update_bir);
            this.Controls.Add(this.tbx_update_tel);
            this.Controls.Add(this.tbx_update_name);
            this.Controls.Add(this.tbx_update_id);
            this.Controls.Add(this.bnt_add_user);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.textbox_delete);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btn_get_information);
            this.Controls.Add(this.richbox_getname);
            this.Name = "client";
            this.Text = "chat";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richbox_getname;
        private System.Windows.Forms.Button btn_get_information;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textbox_delete;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bnt_add_user;
        private System.Windows.Forms.TextBox tbx_update_id;
        private System.Windows.Forms.TextBox tbx_update_name;
        private System.Windows.Forms.TextBox tbx_update_tel;
        private System.Windows.Forms.TextBox tbx_update_bir;
        private System.Windows.Forms.Label lab_update_id;
        private System.Windows.Forms.Label lab_update_name;
        private System.Windows.Forms.Label lab_update_tel;
        private System.Windows.Forms.Label lab_update_birthday;
    }
}