﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace user_login
{
    public partial class client : Form
    {
        public client()
        {
            InitializeComponent();
        }

        private void btn_get_information_Click(object sender, EventArgs e)
        {
            byte[] message = new byte[1024];
            RequestHttp request;
            if (textBox1.Text == "")
            {
                 request = new RequestHttp("GET", "HTTP/1.1", "/user_infor");
            }
            else
            {
                 request = new RequestHttp("GET", "HTTP/1.1", "/user_infor?user_id=" + textBox1.Text);
            }


            byte[] sendmessage = Encoding.Default.GetBytes(request.Return_http());

            Program.socket.Send(sendmessage);

            int bit = Program.socket.Receive(message);

            string msg=Encoding.Default.GetString(message, 0, bit);
            HTTPResponse response = new HTTPResponse(msg);
            if (statecode.state_code(response) == "重新登录")
            {
                MessageBox.Show(statecode.state_code(response));
                Form1 fm = new Form1();
                fm.Owner = this;
                fm.Show();
                this.Hide();
            }
            else
            {

                richbox_getname.Text = msg;
                MessageBox.Show(statecode.state_code(response));
            }


        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            byte[] message = new byte[1024];
            RequestHttp request;
            if (textbox_delete.Text == "")
            {
                request = new RequestHttp("DELETE", "HTTP/1.1", "/user_infor");
            }
            else
            {
                request = new RequestHttp("DELETE", "HTTP/1.1", "/user_infor?user_id=" + textbox_delete.Text);
            }


            byte[] sendmessage = Encoding.Default.GetBytes(request.Return_http());

            Program.socket.Send(sendmessage);

            int bit = Program.socket.Receive(message);

            string msg = Encoding.Default.GetString(message, 0, bit);
            HTTPResponse response = new HTTPResponse(msg);
            if (statecode.state_code(response) == "重新登录")
            {
                MessageBox.Show(statecode.state_code(response));
                Form1 fm = new Form1();
                fm.Owner = this;
                fm.Show();
                this.Hide();
            }
            else
            {

                richbox_getname.Text = msg;
                MessageBox.Show(statecode.state_code(response));
            }

        }


        private void bnt_add_user_Click(object sender, EventArgs e)
        {
            byte[] message = new byte[1024];

            string data = "user_id:" + tbx_update_id.Text + ",user_name:" + tbx_update_name.Text+
                ",user_tel:"+tbx_update_tel.Text+",user_birthday:"+tbx_update_bir.Text;

            RequestHttp request = new RequestHttp("POST", "HTTP/1.1", "/user_infor", data);

            byte[] sendmessage = Encoding.Default.GetBytes(request.Return_http());

            Program.socket.Send(sendmessage);

            int byt = Program.socket.Receive(message);

            string msg = Encoding.Default.GetString(message, 0, byt);

            HTTPResponse response = new HTTPResponse(msg);

            if (statecode.state_code(response) == "重新登录")
            {
                MessageBox.Show(statecode.state_code(response));
                Form1 fm = new Form1();
                fm.Owner = this;
                fm.Show();
                this.Hide();
            }
            else
            {

                richbox_getname.Text = msg;
                MessageBox.Show(statecode.state_code(response));
            }
            
        }
    }
}
