﻿namespace user_login
{
    partial class regis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbx_user_id = new System.Windows.Forms.TextBox();
            this.tbx_user_password = new System.Windows.Forms.TextBox();
            this.tbx_user_name = new System.Windows.Forms.TextBox();
            this.tbx_user_tel = new System.Windows.Forms.TextBox();
            this.tbx_user_birthday = new System.Windows.Forms.TextBox();
            this.btn_regis = new System.Windows.Forms.Button();
            this.btn_back = new System.Windows.Forms.Button();
            this.lable_id = new System.Windows.Forms.Label();
            this.label_password = new System.Windows.Forms.Label();
            this.lable_name = new System.Windows.Forms.Label();
            this.lable_tel = new System.Windows.Forms.Label();
            this.label_birthday = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbx_user_id
            // 
            this.tbx_user_id.Location = new System.Drawing.Point(142, 31);
            this.tbx_user_id.Name = "tbx_user_id";
            this.tbx_user_id.Size = new System.Drawing.Size(100, 20);
            this.tbx_user_id.TabIndex = 0;
            // 
            // tbx_user_password
            // 
            this.tbx_user_password.Location = new System.Drawing.Point(142, 77);
            this.tbx_user_password.Name = "tbx_user_password";
            this.tbx_user_password.Size = new System.Drawing.Size(100, 20);
            this.tbx_user_password.TabIndex = 1;
            // 
            // tbx_user_name
            // 
            this.tbx_user_name.Location = new System.Drawing.Point(142, 121);
            this.tbx_user_name.Name = "tbx_user_name";
            this.tbx_user_name.Size = new System.Drawing.Size(100, 20);
            this.tbx_user_name.TabIndex = 2;
            // 
            // tbx_user_tel
            // 
            this.tbx_user_tel.Location = new System.Drawing.Point(142, 167);
            this.tbx_user_tel.Name = "tbx_user_tel";
            this.tbx_user_tel.Size = new System.Drawing.Size(100, 20);
            this.tbx_user_tel.TabIndex = 3;
            // 
            // tbx_user_birthday
            // 
            this.tbx_user_birthday.Location = new System.Drawing.Point(142, 218);
            this.tbx_user_birthday.Name = "tbx_user_birthday";
            this.tbx_user_birthday.Size = new System.Drawing.Size(100, 20);
            this.tbx_user_birthday.TabIndex = 4;
            // 
            // btn_regis
            // 
            this.btn_regis.Location = new System.Drawing.Point(36, 268);
            this.btn_regis.Name = "btn_regis";
            this.btn_regis.Size = new System.Drawing.Size(75, 23);
            this.btn_regis.TabIndex = 5;
            this.btn_regis.Text = "注册";
            this.btn_regis.UseVisualStyleBackColor = true;
            this.btn_regis.Click += new System.EventHandler(this.btn_regis_Click);
            // 
            // btn_back
            // 
            this.btn_back.Location = new System.Drawing.Point(167, 268);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(75, 23);
            this.btn_back.TabIndex = 6;
            this.btn_back.Text = "返回";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // lable_id
            // 
            this.lable_id.AutoSize = true;
            this.lable_id.Location = new System.Drawing.Point(33, 38);
            this.lable_id.Name = "lable_id";
            this.lable_id.Size = new System.Drawing.Size(69, 13);
            this.lable_id.TabIndex = 7;
            this.lable_id.Text = "用 户  I  D：";
            // 
            // label_password
            // 
            this.label_password.AutoSize = true;
            this.label_password.Location = new System.Drawing.Point(33, 77);
            this.label_password.Name = "label_password";
            this.label_password.Size = new System.Drawing.Size(67, 13);
            this.label_password.TabIndex = 8;
            this.label_password.Text = "用户密码：";
            // 
            // lable_name
            // 
            this.lable_name.AutoSize = true;
            this.lable_name.Location = new System.Drawing.Point(33, 128);
            this.lable_name.Name = "lable_name";
            this.lable_name.Size = new System.Drawing.Size(67, 13);
            this.lable_name.TabIndex = 9;
            this.lable_name.Text = "用户姓名：";
            // 
            // lable_tel
            // 
            this.lable_tel.AutoSize = true;
            this.lable_tel.Location = new System.Drawing.Point(33, 174);
            this.lable_tel.Name = "lable_tel";
            this.lable_tel.Size = new System.Drawing.Size(67, 13);
            this.lable_tel.TabIndex = 10;
            this.lable_tel.Text = "用户电话：";
            // 
            // label_birthday
            // 
            this.label_birthday.AutoSize = true;
            this.label_birthday.Location = new System.Drawing.Point(33, 221);
            this.label_birthday.Name = "label_birthday";
            this.label_birthday.Size = new System.Drawing.Size(67, 13);
            this.label_birthday.TabIndex = 11;
            this.label_birthday.Text = "用户生日：";
            // 
            // regis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(296, 321);
            this.Controls.Add(this.label_birthday);
            this.Controls.Add(this.lable_tel);
            this.Controls.Add(this.lable_name);
            this.Controls.Add(this.label_password);
            this.Controls.Add(this.lable_id);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.btn_regis);
            this.Controls.Add(this.tbx_user_birthday);
            this.Controls.Add(this.tbx_user_tel);
            this.Controls.Add(this.tbx_user_name);
            this.Controls.Add(this.tbx_user_password);
            this.Controls.Add(this.tbx_user_id);
            this.Name = "regis";
            this.Text = "regis";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbx_user_id;
        private System.Windows.Forms.TextBox tbx_user_password;
        private System.Windows.Forms.TextBox tbx_user_name;
        private System.Windows.Forms.TextBox tbx_user_tel;
        private System.Windows.Forms.TextBox tbx_user_birthday;
        private System.Windows.Forms.Button btn_regis;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Label lable_id;
        private System.Windows.Forms.Label label_password;
        private System.Windows.Forms.Label lable_name;
        private System.Windows.Forms.Label lable_tel;
        private System.Windows.Forms.Label label_birthday;
    }
}