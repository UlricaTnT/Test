﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace user_login
{
    public partial class regis : Form
    {
        public regis()
        {
            InitializeComponent();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form1 fm = new Form1();
            fm.Owner = this;
            fm.Show();
            this.Hide();
        }

        private void btn_regis_Click(object sender, EventArgs e)
        {
            byte[] message = new byte[1024];

            #region//生成请求报文
            string data = "user_id:" + tbx_user_id.Text + ",user_password:" + tbx_user_password.Text+
                 ",user_name:" + tbx_user_name.Text+",user_tel:"+tbx_user_tel.Text+",user_birthday:"+tbx_user_birthday.Text;
            RequestHttp request = new RequestHttp("PUT", "HTTP/1.1", "/user_infor", data);
            byte[] sendmessage = Encoding.Default.GetBytes(request.Return_http());
            #endregion


            Program.socket.Send(sendmessage);

            int byt = Program.socket.Receive(message);

            string msg = Encoding.Default.GetString(message, 0, byt);
            HTTPResponse response = new HTTPResponse(msg);

            if (statecode.state_code(response)=="成功")
            {
                MessageBox.Show("注册成功");
                Form1 fm = new Form1();
                fm.Owner = this;
                fm.Show();
                this.Hide();
            }

            else if (statecode.state_code(response) == "重新登录")
            {
                MessageBox.Show(statecode.state_code(response));
                Form1 fm = new Form1();
                fm.Owner = this;
                fm.Show();
                this.Hide();
            }

        }
    }
}
