﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace user_login
{
    public class statecode
    {
        public static string state_code(HTTPResponse response)
        {
            string return_string="";
            if (response.statecode.Split(' ')[0] == "200")
            {
                return_string = "成功";
                return return_string;
            }
            else if (response.statecode.Split(' ')[0] == "404")
            {
                return_string = "未找到对应资源";
                return return_string;
            }
            else if (response.statecode.Split(' ')[0] == "402")
            {
                return_string = "重新登录";
                return return_string;
            }
            else if (response.statecode.Split(' ')[0] == "500")
            {
                return_string = "服务器错误";
                return return_string;
            }
            else if (response.statecode.Split(' ')[0] == "202")
            {
                return_string = "账号已存在，请重新输入";
                return return_string;
            }
            else if (response.statecode.Split(' ')[0] == "401")
            {
                return_string = "账号密码错误";
                return return_string;
            }
            else
                return return_string;
        }
    }
}
