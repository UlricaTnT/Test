﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace user_server
{
    public class Analysistype
    {
        /// <summary>
        /// 将对象转换为客户端需要的类型
        /// </summary>
        /// <param name="a">需要转换的对象</param>
        /// <param name="type">需要转换的格式</param>
        /// <returns></returns>
        public static List<string> analy(object a, string type)
        {
            bool isanaly = false;
            List<string> return_value = new List<string>();

            foreach (var s in type.Split(','))
            {
                if (s == "text/json")
                {
                    string data = JsonConvert.SerializeObject(a);
                    return_value.Add(s);
                    return_value.Add(Encoding.Default.GetBytes(data).Length.ToString());
                    return_value.Add(data);
                    return_value.Add("200 OK");
                    isanaly = true;
                    break;
                }
            }
            if (!isanaly)
            {
                object ob = new { message = "error accept", hope = "text/json" };
                string data = JsonConvert.SerializeObject(ob);
                return_value.Add("text/json");
                return_value.Add(Encoding.Default.GetBytes(data).Length.ToString());
                return_value.Add(data);
                return_value.Add("203 OK");
            }
            return return_value;



        }

        /// <summary>
        /// 将对象转换为客户端需要的类型
        /// </summary>
        /// <param name="a">需要转换的对象</param>
        /// <param name="type">客户端需要的类型</param>
        /// <returns></returns>
        public static List<string> analy(object[] a, string type)
        {
            bool isanaly = false;
            List<string> return_value = new List<string>();

            foreach (var s in type.Split(','))
            {
                if (s == "text/json")
                {
                    string data = "";
                    data += JsonConvert.SerializeObject(a);
                    return_value.Add(s);
                    return_value.Add(Encoding.Default.GetBytes(data).Length.ToString());
                    return_value.Add(data);
                     
                }
                if (s == " text/html")
                {
                    string data = "";
                    data += "<HTML><HEAD><TITLE>USER</TITLE><BODY>";
                    foreach (var ob in a)
                    {
                        data += "<p>" + ob + "</p>";
                        
                    }
                    data += "</BODY></HTML>";
                    return_value.Add(s);
                    return_value.Add(Encoding.Default.GetBytes(data).Length.ToString());
                    return_value.Add(data);
                }
            }
            if (!isanaly)
            {
                object ob = new { message = "error accept", hope = "text/json" };
                string data = JsonConvert.SerializeObject(ob);
                return_value.Add("text/json");
                return_value.Add(Encoding.Default.GetBytes(data).Length.ToString());
                return_value.Add(data);
                return_value.Add("203 error accept");
            }
            return return_value;
        }
    }
}
