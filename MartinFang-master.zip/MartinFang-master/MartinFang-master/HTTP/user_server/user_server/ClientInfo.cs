﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Net;

namespace user_server
{
    public class ClientInfo
    {
        public byte[] buffer;
        public bool isnull = true;
        public List<HttpReaquest> request = new List<HttpReaquest>();

        /// <summary>
        /// 处理客户端请求，生成响应报文
        /// </summary>
        /// <returns></returns>
        public string response()
        {
            string returnvalue = "";
             //加载当前程序集
            Assembly assm = Assembly.GetExecutingAssembly();

            //获取当前的url，判断url是否在全局的路由表中
            if (!routclass.rout.ContainsKey(request[0].url))
            {
                StringBuilder response_string = new StringBuilder();
                response_string.Append("HTTP/1.1 404 not found");
                response_string.Append("Date:" + DateTime.Now.ToString());
                return response_string.ToString();

            }

            else
            {
                //将对象转换为接口类型，方法的调用
                IROUT irout = (IROUT)assm.CreateInstance(routclass.rout[request[0].url]);

                HTTPResponse response = new HTTPResponse();

                //判断当前用户的会话时间是否超时，或还没有建立过连接
                if (!request[0].header.ContainsKey("Cookie") || !session.Session.ContainsKey(request[0].header["Cookie"]))
                {
                    response.version = "HTTP/1.1";
                    response.statecode = "402 Expired";
                    string s = Guid.NewGuid().ToString();
                    response.header.Add("Date", DateTime.Now.ToString());
                    session.Session[s] = DateTime.Now.AddMinutes(3);
                    response.header.Add("Cookie", s);

                }
                else
                {
                    if (request[0].method == "POST")
                    {
                        //调用方法
                        response = irout.Post(request[0]);
                        //重置当前会话超时时间
                       session.Session[request[0].header["Cookie"]] = DateTime.Now.AddMinutes(3);

                    }
                    if (request[0].method == "GET")
                    {
                        response = irout.Get(request[0]);
                        session.Session[request[0].header["Cookie"]] = DateTime.Now.AddMinutes(3);

                    }
                    if (request[0].method == "PUT")
                    {
                        response = irout.Put(request[0]);
                       session.Session[request[0].header["Cookie"]] = DateTime.Now.AddMinutes(3);

                    }
                    if (request[0].method == "DELETE")
                    {
                        response = irout.Delete(request[0]);
                       session.Session[request[0].header["Cookie"]] = DateTime.Now.AddMinutes(3);

                    }
            }
            returnvalue = HTTPResponse.response_to_string(response);
            }
            return returnvalue;
        }

    }
}
