﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace user_server
{
    public class HTTPResponse
    {
        public string version;
        public string statecode;
        public Dictionary<string, string> header=new Dictionary<string, string>();
        public object data=new object();

        /// <summary>
        /// 将httpresponse对象转换为响应报文
        /// </summary>
        /// <param name="a">HTTPResponse对象</param>
        /// <returns></returns>
        public static string response_to_string(HTTPResponse a)
        {
            StringBuilder rstring = new StringBuilder();
            rstring.Append(a.version + " " + a.statecode + "\r\n");
            foreach (var hea in a.header)
            {
                rstring.Append(hea.Key + ":" + hea.Value + "\r\n");
            }
            rstring.Append("\r\n");
            if(a.data.ToString() !="System.Object")
                rstring.Append(a.data);
            return rstring.ToString();

        }
    }
}
