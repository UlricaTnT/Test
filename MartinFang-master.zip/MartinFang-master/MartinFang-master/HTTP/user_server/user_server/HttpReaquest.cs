﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace user_server
{
    public class HttpReaquest
    {
        public string method;
        public string version;
        public string url;
        public Dictionary<string, string> header=new Dictionary<string, string>();
        public Dictionary<string, string> query = new Dictionary<string, string>();
        public Dictionary<string, string> form = new Dictionary<string, string>();

        /// <summary>
        /// 解析http请求
        /// </summary>
        /// <param name="data">报文</param>
        public HttpReaquest(string data)
        {
            Regex regex = new Regex("\r\n");
            string[] _data = regex.Split(data);
            method = _data[0].Split(' ')[0];
            version = _data[0].Split(' ')[2];
            if (method == "GET" || method == "DELETE")
            {
                string[] quer = _data[0].Split(' ')[1].Split('?');
                url = quer[0];
                if (quer.Length != 1)
                {
                    string[] querys = quer[1].Split('&');
                    for (int i = 0; i < querys.Length; i++)
                    {
                        string[] par = querys[i].Split('=');
                        query.Add(par[0], par[1]);
                    }
                }
            }
            else if (method == "POST")
            {
                url = _data[0].Split(' ')[1];
                string[] forms = _data[_data.Length - 2].Split(',');
                foreach (var f in forms)
                {
                    string[] fo = f.Split(':');
                    form.Add(fo[0], fo[1]);
                }

            }
            else if(method=="PUT")
            {
                string[] quer = _data[0].Split(' ')[1].Split('?');
                url = quer[0];
                if (quer.Length != 1)
                {
                    string[] querys = quer[1].Split('&');
                    for (int i = 0; i < querys.Length; i++)
                    {
                        string[] par = querys[i].Split('=');
                        query.Add(par[0], par[1]);
                    }
                }
                string[] forms = _data[_data.Length - 2].Split(',');
                foreach (var f in forms)
                {
                    string[] fo = f.Split(':');
                    form.Add(fo[0], fo[1]);
                }
            }

            for (int i = 1; i < _data.Length; i++)
            {
                if (_data[i] == "")
                    break;
                else
                {
                    Regex regexs = new Regex(":");
                    string[] par = regexs.Split(_data[i],2);
                    header.Add(par[0], par[1]);
                }
            }


        }
    }
}
