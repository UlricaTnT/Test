﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace user_server
{
    /// <summary>
    /// 申明一个借口，主要作用是为了实例化对象后的方法调用
    /// </summary>
    public interface IROUT
    {
        HTTPResponse Get(HttpReaquest request);

        HTTPResponse Post(HttpReaquest request);

        HTTPResponse Put(HttpReaquest request);

        HTTPResponse Delete(HttpReaquest request);

        HTTPResponse Options(Dictionary<string, string> a);
    }
}
