﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.Text.RegularExpressions;
using System.Security.Cryptography;
using System.Reflection;

namespace user_server
{
    /// <summary>
    /// 全局路由表
    /// </summary>
    public static class routclass
    {
        public static Dictionary<string, string> rout = new Dictionary<string, string>();
    }

    /// <summary>
    /// 全局会话表，当前用户的会话时间是否过期
    /// </summary>
    public static class session
    {
        public static Dictionary<string,DateTime> Session = new Dictionary<string, DateTime>();
    }
    
    class Program
    {
        
        static void Main(string[] args)
        {
            #region 设置全局变量路由表
            //加载当前程序集
            Assembly assm = Assembly.GetExecutingAssembly();
            Type[] a = assm.GetTypes();
            //遍历所有的类，查找属性加入路由表
            foreach (Type ta in a)
            {
                if (urlAttribute.IsDefined(ta, typeof(urlAttribute)))
                {
                    Attribute[] o = urlAttribute.GetCustomAttributes(ta);
                    foreach (var attr in o)
                    {
                        urlAttribute attrs = (urlAttribute)attr;
                        routclass.rout.Add(attrs.geturl(), attrs.getname());
                    }
                }
            }
            #endregion 

            //打通连接，任督二脉
            TCPhelper helper = new TCPhelper();
            helper.run();
        }

    }
}
