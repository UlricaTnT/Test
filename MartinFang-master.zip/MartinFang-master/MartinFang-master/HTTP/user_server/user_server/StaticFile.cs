﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.IO;

namespace user_server
{
    public static class StaticFile
    {
        public static bool FindFile(string url)
        {
            string path1 = url.Replace('/', '\\');
            string path = System.Environment.CurrentDirectory + path1;
            return File.Exists(path);
        }
        public static void FindStaticFile(Socket client, string url)
        {
            string path1 = url.Replace('/', '\\');
            string path = System.Environment.CurrentDirectory + path1;
            string data = File.ReadAllText(path);
            string message = "HTTP / 1.1 200 OK \r\n" +
                "Content-Length:" + data.Length + "\r\n" +
                "Content-type:text/html" + "\r\n" +
                "Date:" + DateTime.Now.ToUniversalTime().ToString() + "\r\n"
                + "\r\n" +
                data;
            client.Send(Encoding.Default.GetBytes(message));
        }
    }
}
