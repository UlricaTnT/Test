﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Threading;
using System.Net;
using System.IO;
namespace user_server
{
    public class TCPhelper
    {
        private Dictionary<Socket, ClientInfo> clientpool = new Dictionary<Socket, ClientInfo>();
        public void run()
        {
            Console.WriteLine("服务器启动：" + DateTime.Now.ToShortDateString());
            //创建一个线程，能够循环的接听多个客户端连接
            Thread serverthread = new Thread(() =>
            {
                Socket server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                server.Bind(new IPEndPoint(IPAddress.Any, 8087));
                server.Listen(10);
                server.BeginAccept(new AsyncCallback(Accept), server);
            }
            );
            serverthread.Start();
            Console.WriteLine("server is ready");
            BroadCast();
            destroysession();
        }

           /// <summary>
           /// 循环监听全局会话表，如果长时间不操作客户端，需要重新登录
           /// </summary>
        public void destroysession()
        {
            Thread destory = new Thread(() =>
              {
                  while (true)
                  {
                      if (session.Session.Count == 0)
                      {
                          continue;
                      }
                      else
                      {
                          List<string> deletestring = new List<string>();
                          foreach (KeyValuePair<string, DateTime> cs in session.Session)
                          {
                              if (cs.Value < DateTime.Now)
                              {
                                  deletestring.Add(cs.Key);
                              }
                          }
                          foreach (string de in deletestring)
                          {
                              session.Session.Remove(de);
                          }
                      }
                      Thread.Sleep(100);
                  }
                  
              });
            destory.Start();
        }

        /// <summary>
        /// 循环监听消息队列，让每一个从客户端进来的请求能够得到处理
        /// </summary>
        private void BroadCast()
        {
            Thread broadcast = new Thread(() =>
            {
                while (true)
                {
                    for (int i = 0; i < clientpool.Count(); i++)
                    {
                        foreach (KeyValuePair<Socket, ClientInfo> cs in clientpool)
                        {
                            Socket client = cs.Key;
                            
                            if (!clientpool[client].isnull)
                            {
                                byte[] msg = Encoding.Default.GetBytes(clientpool[client].response());
                                client.Send(msg);
                                clientpool[client].request.RemoveAt(0);
                                
                                
                            }
                            if (clientpool[client].request.Count() == 0)
                                clientpool[client].isnull = true;


                        }


                    }
                    //线程等待200毫秒，作用是有些客户端断开连接的时候，对于资源的冲突
                    Thread.Sleep(200);
                }


            });

            broadcast.Start();
        }

        /// <summary>
        /// 异步接受客户端连接
        /// </summary>
        /// <param name="socket">连接过来的客户端</param>
        private void Accept(IAsyncResult socket)
        {

            Socket server = socket.AsyncState as Socket;
            Socket client = server.EndAccept(socket);
            try
            {
                server.BeginAccept(new AsyncCallback(Accept), server);
                byte[] buffer = new byte[1024];
                Console.WriteLine("来自" + client.RemoteEndPoint + "的连接");               
                ClientInfo info = new ClientInfo();
                info.buffer = buffer;
                clientpool.Add(client, info);
                client.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, new AsyncCallback(Recieve), client);
            }
            catch (Exception ex)
            {
                Console.WriteLine("error");
            }


        }


        /// <summary>
        /// 异步接受客户端请求
        /// </summary>
        /// <param name="result">异步过来的客户端</param>
        private void Recieve(IAsyncResult result)
        {
            Socket client = result.AsyncState as Socket;
            if (client == null)
            {
                return;
            }
            try
            {
                int length = client.EndReceive(result);
                Byte[] buffer = clientpool[client].buffer;
                
                //buffer = Encoding.Default.GetBytes(msg);
                client.BeginReceive(buffer, 0, buffer.Length, SocketFlags.None, new AsyncCallback(Recieve), client);
                string msg = Encoding.Default.GetString(buffer, 0, length);
                HttpReaquest http = new HttpReaquest(msg);
                //判断是否为物理文件，是则直接返回
                if (StaticFile.FindFile(http.url))
                {
                    StaticFile.FindStaticFile(client, http.url);
                }
                else
                {
                    clientpool[client].isnull = false;
                    clientpool[client].request.Add(http);
                }


            }
            catch (Exception e)
            {
                //client.Close();
                //clientpool.Remove(client);
            }
        }
    }


}
