﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace user_server
{
    /// <summary>
    /// user_login 类 对应/user_login 的url
    /// 继承自irout接口，主要是为了方法调用
    /// </summary>
    [url(url = "/user_login", classname = "user_server.user_login")]
    public class user_login : IROUT
    {
        public HTTPResponse Delete(HttpReaquest request)
        {
            HTTPResponse response = new HTTPResponse();
            response.version = "HTPP/1.1";
            response.statecode = "404 NOTFOUND";
            return response;
        }

        public HTTPResponse Options(Dictionary<string, string> a)
        {
            HTTPResponse response = new HTTPResponse();
            response.version = "HTPP/1.1";
            response.statecode = "404 NOTFOUND";
            return response;
        }

        public HTTPResponse Get(HttpReaquest request)
        {
            HTTPResponse response = new HTTPResponse();
            response.version = "HTPP/1.1";
            response.statecode = "404 NOTFOUND";
            return response;
        }

        /// <summary>
        /// 响应客户端的post请求，登录请求
        /// </summary>
        /// <param name="request">客户端请求</param>
        /// <returns></returns>
        public HTTPResponse Post(HttpReaquest request)
        {
            HTTPResponse response = new HTTPResponse();
            string errorcode = "";
            try
            {
                foreach (var user in users.usinfo)
                {
                    if (request.form["user_id"] == user.user_id && request.form["user_password"] == user.user_password)
                    {
                        response.statecode = "200 OK";
                                               
                       break;
                    }
                    else
                    {
                        response.statecode = "401 OK";

                    }
                }
                response.version = "HTPP/1.1";
                response.header.Add("DATE", DateTime.Now.ToString());
                response.header.Add("Content-Type", "text/json");
                response.header.Add("Content-Length", errorcode.Length.ToString());
            }
            catch (Exception e)
            {
                response.version = "HTPP/1.1";
                response.statecode = "500 ERROR";
                response.header.Add("DATE", DateTime.Now.ToString());
                response.header.Add("Content-Type", "text/json");
                response.header.Add("Content-Length", errorcode.Length.ToString());

            }



            return response;
        }

        public HTTPResponse Put(HttpReaquest request)
        {
            HTTPResponse response = new HTTPResponse();
            response.version = "HTPP/1.1";
            response.statecode = "404 NOTFOUND";
            return response;
        }

    }

    [url(url = "/user_infor", classname = "user_server.user_infor")]
    public class user_infor : IROUT
    {
        public HTTPResponse Delete(HttpReaquest request)
        {
            HTTPResponse response = new HTTPResponse();

            try
            {
                if (!request.query.ContainsKey("user_id"))
                {
                    response.statecode = "404 NOT FOUND";
                }
                else
                {
                    foreach (var user in users.usinfo)
                    {
                        if (user.user_id == request.query["user_id"])
                        {
                            users.usinfo.Remove(user);
                            response.statecode = "200 OK";
                            break;
                        }
                        else
                        {
                            response.statecode = "404 NOT FOUND";
                        }
                    }
                }
                response.version = "HTPP/1.1";

                response.header.Add("DATE", DateTime.Now.ToString());
                response.header.Add("Content-Type", "text/json");
                response.header.Add("Content-Length", 0.ToString());
                return response;

            }
            catch (Exception e)
            {
                response.version = "HTPP/1.1";
                response.statecode = "500 ERROR";
                response.header.Add("DATE", DateTime.Now.ToString());
                response.header.Add("Content-Type", "text/json");
                response.header.Add("Content-Length", 0.ToString());
                return response;
            }
        }

        public HTTPResponse Get(HttpReaquest request)
        {
            HTTPResponse response = new HTTPResponse();

            try
            {
                if (!request.query.ContainsKey("user_id"))
                {
                    object[] s = new object[users.usinfo.Count()];
                    for (int i = 0; i < s.Length; i++)
                    {
                        s[i] = new
                        {
                            name = users.usinfo[i].name,
                            tel = users.usinfo[i].tel,
                            birthday = users.usinfo[i].birthday
                        };
                    }

                    List<string> list = Analysistype.analy(s, request.header["Accept"]);
                    response.version = "HTTP / 1.1";
                    response.statecode = "200 OK";
                    response.header.Add("Content-Length", list[1]);
                    // response.header.Add("Transfer-Encoding", "chunked");
                    response.header.Add("Content-Type", list[0]);
                    response.header.Add("Date", DateTime.Now.ToUniversalTime().ToString());
                    response.data = list[2];
                    return response;
                }
                else
                {
                    foreach (var user in users.usinfo)
                    {

                        if (request.query["user_id"] == user.user_id)
                        {
                            object s = new { name = user.name, tel = user.tel, birthday = user.birthday };

                            List<string> list = Analysistype.analy(s, request.header["Accept"]);
                            response.version = "HTTP / 1.1";
                            response.statecode =list[3];
                            response.header.Add("Content-Length", list[1]);
                            response.header.Add("Content-Type", list[0]);
                            response.header.Add("Date", DateTime.UtcNow.ToShortDateString());
                            response.data = list[2];
                            return response;
                        }
                        else
                        {
                            response.version = "HTPP/1.1";
                            response.statecode = "404 NOTFOUND";
                        }

                    }
                    response.header.Add("DATE", DateTime.Now.ToString());
                    response.header.Add("Content-Type", "text/json");
                    return response;
                }

            }
            catch (Exception e)
            {
                response.version = "HTPP/1.1";
                response.statecode = "500 ERROR";
                response.header.Add("DATE", DateTime.Now.ToString());
                response.header.Add("Content-Type", request.header["Accept"]);
                return response;
            }



        }

        public HTTPResponse Options(Dictionary<string, string> a)
        {
            HTTPResponse response = new HTTPResponse();
            response.version = "HTPP/1.1";
            response.statecode = "404 NOTFOUND";
            return response;
        }

        public HTTPResponse Post(HttpReaquest request)
        {

            HTTPResponse response = new HTTPResponse();

            try
            {
                for (int i = 0; i < users.usinfo.Count(); i++)
                {
                    if (users.usinfo[i].user_id == request.form["user_id"])
                    {
                        if (request.form["user_name"] != "")
                            users.usinfo[i].name = request.form["user_name"];
                        if (request.form["user_tel"] != "")
                            users.usinfo[i].tel = request.form["user_tel"];
                        if (request.form["user_birthday"] != "")
                            users.usinfo[i].birthday = request.form["user_birthday"];
                        response.statecode = "200 OK";
                        break;
                    }
                    response.statecode = "404 NOTFOUND";
                }
                if (users.usinfo.Count() == 0)
                    response.statecode = "404 NOTFOUND";
                response.version = "HTPP/1.1";
                response.header.Add("DATE", DateTime.Now.ToString());
                response.header.Add("Content-Type", "text/json");
                response.header.Add("Content-Length", 0.ToString());
                return response;

            }
            catch (Exception e)
            {
                response.version = "HTPP/1.1";
                response.statecode = "500 ERROR";
                response.header.Add("DATE", DateTime.Now.ToString());
                response.header.Add("Content-Type", "text/json");
                response.header.Add("Content-Length", 0.ToString());
                return response;
            }


        }

        public HTTPResponse Put(HttpReaquest request)
        {
            HTTPResponse response = new HTTPResponse();

            response.version = "HTTP/1.1";

            try
            {

                foreach (var user in users.usinfo)
                {
                    if (user.user_id == request.form["user_id"])
                    {
                        response.statecode = "202 user_id_is_state";
                        response.header.Add("DATE", DateTime.Now.ToString());
                        return response;
                    }
                }
                users.usinfo.Add(
                    new user
                    (
                        request.form["user_name"],
                        request.form["user_tel"],
                        request.form["user_birthday"],
                        request.form["user_id"],
                        request.form["user_password"]
                     ));
                response.statecode = "200 OK";
                response.header.Add("DATE", DateTime.Now.ToString());
                return response;
            }
            catch (Exception e)
            {
                response.statecode = "500 error";
                response.header.Add("DATE", DateTime.Now.ToString());
                return response;
            }

        }

    }

    public class user
    {
        public string name;
        public string tel;
        public string birthday;
        public string user_id;
        public string user_password;

        public user(string _name, string _tel, string _birthday, string _userid, string _userpassword)
        {
            name = _name;
            tel = _tel;
            birthday = _birthday;
            user_id = _userid;
            user_password = _userpassword;
        }
    }

    public static class users
    {
        public static List<user> usinfo = new List<user>()
        {
            new user("martin1","13032307191","2017-4-10","1036263401","123451"),
            new user("martin2","13032307192","2017-4-11","1036263402","123452"),
            new user("martin3","13032307193","2017-4-12","1036263403","123453"),
            new user("martin4","13032307194","2017-4-13","1036263404","123454"),
            new user("martin5","13032307195","2017-4-14","1036263405","123455"),
            new user("martin6","13032307196","2017-4-15","1036263406","123456"),
            new user("martin7","13032307197","2017-4-16","1036263407","123457"),
            new user("martin8","13032307198","2017-4-17","1036263408","123458")
        };
    }
}
