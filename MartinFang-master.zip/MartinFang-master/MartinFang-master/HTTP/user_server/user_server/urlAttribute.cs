﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace user_server
{
    /// <summary>
    /// 定义一个自定义的属性，主要为了路由表的创建
    /// </summary>
    [AttributeUsageAttribute(AttributeTargets.Class|AttributeTargets.Property,Inherited =true)]
    class urlAttribute:Attribute
    {
        public string url;
        public string classname;

        public string getname()
        {
            return classname;
        }
        public string geturl()
        {
            return url;
        }
    }
}
