---------------------------------------------------------------------����һ------------------------------------------
---------------------------------------------------------------------------------------------------------------------
USE Test
GO
/*����schema*/
CREATE SCHEMA bank
GO

---------------------------------------------------------------------�����------------------------------------------
---------------------------------------------------------------------------------------------------------------------

/*�����û���*/
USE Test
GO
CREATE TABLE [bank].[Customer_mf57]
(
	ID					INT IDENTITY(1,1)	NOT NULL
	,CustomerID         NCHAR(18)			NOT NULL
	,Name               NVARCHAR(150)		NOT NULL
	,Phone              VARCHAR(25)			NOT NULL
	,CustomerAddress    NVARCHAR(300)		NOT NULL
	,CreatTime			DATETIME			NOT NULL	DEFAULT GETDATE()
	,LastEditDate		DATETIME			NOT NULL	DEFAULT GETDATE()
	,Remarks			NVARCHAR(300)		NULL
	,CONSTRAINT PK_Customer_CustomerID PRIMARY KEY
	(
		ID ASC
	) 
	
)
GO

/*�������п���*/
CREATE TABLE [bank].[Debit_Card_mf57]
(
	ID						VARCHAR(20)			NOT NULL
	,CustomerID				NCHAR(18)			NOT NULL 
	,DebitCardPassword		VARCHAR(50)			NOT NULL
	,Balance				DECIMAL(12,2)		NOT NULL
	,IsVip					BIT					NOT NULL
	,DebitCardStatus		BIT					NOT NULL
	,CreatTime				DATETIME			NOT NULL	DEFAULT GETDATE()
	,LastEditDate			DATETIME			NOT NULL	DEFAULT GETDATE()
	,Remarks				NVARCHAR(300)		NULL
	,CONSTRAINT PK_DebitCrad_DebitCardID PRIMARY KEY
	(
		ID ASC
	)
	,CONSTRAINT FK_DebitCard_Customer_CustomerID FOREIGN KEY(CustomerID)
	REFERENCES [bank].Customer_mf57(CustomerID)
	
)
GO

/*���������¼��*/
CREATE TABLE [bank].[Transactions_mf57]
(
	TransactionNumber		INT IDENTITY(1,1)		NOT NULL
	,Card_ID				VARCHAR(20)				NOT NULL 
	,TransactionType		Nvarchar(2)				NOT NULL
	,Amount					INT						NOT NULL
	,Indate					DATETIME				NOT NULL	DEFAULT GETDATE()
	,TransactionStatus		BIT						NOT NULL
	,Reamarks				NVARCHAR				NULL
	,CONSTRAINT PK_Transaction_TransactionNumber PRIMARY KEY
	(
		TransactionNumber ASC
	)
	,CONSTRAINT FK_Transaction_DebitCard_ID FOREIGN KEY(Card_ID)
		 REFERENCES [bank].[Debit_Card_mf57](ID)

)
GO

---------------------------------------------------------------------������------------------------------------------
---------------------------------------------------------------------------------------------------------------------
USE [Test]
INSERT INTO bank.Customer_mf57
(
	[CustomerID]
	,[Name]
	,[Phone]
	,[CustomerAddress]
)
SELECT '610524198807330846',N'����','13438995253',N'�Ĵ�ʡ�ɶ��и������츮���1888��'
UNION ALL
SELECT '610524198807340846',N'����','13434995253',N'�Ĵ�ʡ�ɶ��и������츮���1880��'
UNION ALL
SELECT '610524198807340842',N'����','13424995253',N'�Ĵ�ʡ�ɶ��и������츮���'
GO

---------------------------------------------------------------------������------------------------------------------
---------------------------------------------------------------------------------------------------------------------
USE [Test]
GO

SELECT TOP(100) 
	Name AS 'Name'
	,CUS.CustomerID AS 'CardID'
	,COUNT(*) AS 'TranNumber'
	,Phone AS 'Phone'
	,CustomerAddress AS 'Address'
	,SUM(TR.Amount) AS 'AmountSum'
	,(
		SELECT SUM(DE.Balance)
		FROM bank.Debit_Card_mf57 AS DE WITH (NOLOCK)
		WHERE CustomerID=CUS.CustomerID) AS 'Amount'
FROM bank.Customer_mf57 AS CUS  WITH(NOLOCK)
		INNER JOIN bank.Debit_Card_mf57 AS DEBIT WITH(NOLOCK)
		ON CUS.CustomerID=DEBIT.CustomerID
		INNER JOIN bank.Transactions_mf57 AS TR WITH(NOLOCK)
		ON TR.Card_ID=DEBIT.ID
WHERE  TransactionStatus='1'
		AND Indate>DATEADD(MONTH,-6,GETDATE())
GROUP BY CUS.CustomerID,CUS.Name,Phone,CustomerAddress,DEBIT.Balance
ORDER BY SUM(TR.Amount) DESC
--ORDEY BY COUNT(*) DESC

---------------------------------------------------------------------������------------------------------------------
---------------------------------------------------------------------------------------------------------------------

USE [Test]
GO
DECLARE @STRING VARCHAR(MAX),@I INT,@SUBSTRING VARCHAR(50)

IF OBJECT_ID(N'tempdb.dbo.#STR',N'U') IS NOT NULL
   DROP TABLE #STR

CREATE TABLE #STR(VALUE VARCHAR(50))

SET @STRING='01;03;02;06;08;04;01;03;09;;20;12;1;24;25;87'
WHILE (SELECT LEN(@STRING))>1
	BEGIN
		SELECT @I=CHARINDEX(';', @STRING)
		IF(SELECT @I)=0
			BEGIN
				IF NOT EXISTS (SELECT * FROM #STR WITH(NOLOCK) WHERE VALUE=@STRING)
					BEGIN
						INSERT INTO #STR
						(
							[VALUE]
						)
						SELECT @STRING
						
					END
				BREAK
			END
			
		ELSE
			BEGIN
				SELECT @SUBSTRING=SUBSTRING(@STRING,0,@I)
				SELECT @STRING=RIGHT(@STRING,LEN(@STRING)-@I)
				IF NOT EXISTS (SELECT * FROM #STR WITH(NOLOCK) WHERE VALUE=@SUBSTRING)
					BEGIN
						INSERT INTO #STR	
						(
							[VALUE]
						)
						SELECT @SUBSTRING
					END
			END

	END
INSERT INTO bank.substring_mf57([VALUE]) SELECT [VALUE] FROM #STR