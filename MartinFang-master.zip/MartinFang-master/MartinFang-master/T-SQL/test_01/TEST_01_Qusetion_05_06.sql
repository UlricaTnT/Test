/******************************************************************
**DB:Test
**Type:Procedure
**ObjectName:Bank.P_Transfer
**team:intern
**Creater:Martin
**Create date:2017-7-26
**Modify by:
**Modify date:
**Function:transfer 
**Variable:1.0
*************************************************************************/
USE Test
GO
ALTER PROC P_Transfer
(
	@TransferoutID VARCHAR(20)
	,@OutBanlance DECIMAL(12,2)
	,@TransferToID VARCHAR(20)
	,@name NVARCHAR(150)
	,@returnvalue INT OUTPUT
 )
 AS 
 BEGIN
	 DECLARE @REMARKS NVARCHAR(300)
	 IF EXISTS (SELECT TOP 1 1 
				FROM [bank].[Debit_Card_mf57] WITH (NOLOCK)
				WHERE DebitCardStatus='TRUE'
						AND ID=@TransferoutID)
		BEGIN
			IF EXISTS (SELECT TOP 1 1
						FROM [bank].[Debit_Card_mf57] WITH (NOLOCK)
						WHERE Balance>@OutBanlance
								AND ID=@TransferoutID
						)
				BEGIN
					IF EXISTS (SELECT TOP 1 1
								FROM [bank].[Debit_Card_mf57] WITH(NOLOCK)
									,[bank].[Customer_mf57] WITH(NOLOCK)
								WHERE DebitCardStatus=1
										AND [Debit_Card_mf57].CustomerID=Customer_mf57.CustomerID
										AND [Debit_Card_mf57].ID=@TransferToID
										AND Name=@name
										)
						BEGIN
							BEGIN TRY
								BEGIN TRAN;
									UPDATE [bank].[Debit_Card_mf57]SET Balance=Balance-@OutBanlance WHERE ID=@TransferoutID

									UPDATE [bank].[Debit_Card_mf57]SET Balance=Balance+@OutBanlance WHERE ID=@TransferToID
														
									INSERT INTO [bank].[Transactions_mf57]
										(
											card_id
											,TransactionType
											,Amount
											,TransactionStatus	
										)
										SELECT	@TransferoutID,N'֧��',@OutBanlance,1
										UNION ALL
										SELECT @TransferToID,N'����',@OutBanlance,1										

								set @returnvalue=1
								COMMIT TRAN;
							
							END TRY
							BEGIN CATCH

								ROLLBACK TRAN

								set @REMARKS=N'system error'

								INSERT INTO [bank].[Transactions_mf57]
										(
											card_id
											,TransactionType
											,Amount
											,TransactionStatus
											,Reamarks	
										)
										SELECT @TransferoutID,N'����',@OutBanlance,0,@REMARKS
										UNION ALL
										SELECT @TransferoutID,N'֧��',@OutBanlance,0,@REMARKS

								set @returnvalue=-1

							END CATCH
						END
				
					ELSE
						BEGIN
							set @REMARKS=N'Account or name wrong'

							INSERT INTO [bank].[Transactions_mf57]
									(
										card_id
										,TransactionType
										,Amount
										,TransactionStatus
										,Reamarks	
									)
									SELECT @TransferoutID,N'����',@OutBanlance,0,@REMARKS
									UNION ALL
									SELECT @TransferoutID,N'֧��',@OutBanlance,0,@REMARKS
										

							set @returnvalue=-1
						END
				END
			ELSE
				BEGIN
					set @REMARKS=N'Balance is not enough'
					INSERT INTO [bank].[Transactions_mf57]
								(
									card_id
									,TransactionType
									,Amount
									,TransactionStatus
									,Reamarks	
								)
								SELECT @TransfertoID,N'����',@OutBanlance,0,@REMARKS
								UNION ALL
								SELECT @TransferoutID,N'֧��',@OutBanlance,0,@REMARKS

					set @returnvalue=-1
				END
		END 
	 ELSE 
		BEGIN
			set @REMARKS=N'card error'
			INSERT INTO [bank].[Transactions_mf57]
						(
							card_id
							,TransactionType
							,Amount
							,TransactionStatus
							,Reamarks	
						)
						SELECT @TransferoutID,N'����',@OutBanlance,0,@REMARKS
						UNION ALL
						SELECT @TransferoutID,N'֧��',@OutBanlance,0,@REMARKS

			SET @returnvalue=-1
		END

 END
 GO


DECLARE @TransferoutID		VARCHAR(20)
		,@OutBanlance		DECIMAL(12,2)
		,@TransferToID		VARCHAR(20)
		,@name				NVARCHAR(150)
		,@returnvalue		INT


SELECT @TransferoutID='1234567891'
		,@OutBanlance=500.00
		,@name=N'����'
		,@TransferToID='123456789'



EXEC P_Transfer @TransferoutID,@OutBanlance,@TransferToID,@name,@returnvalue