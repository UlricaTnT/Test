/******************************************************************
*name        :  Test.bank.P_Archive_Transaction_Year_Data
*function    :  Archive The Transaction_Year_Data
*input       :  NULL
*output      :  ReturnValue
Table Used   :
*	------------------------------------------------------- 

*author      :  Martin Fang	
*server		 :  SQL SERVER
*CreateDate  :  2017-7-29
*************************************************************************/
USE Test
GO
CREATE PROC [bank].P_Archive_Transaction_Year_Data
(	

	@returnvalue VARCHAR(50) OUTPUT
)
AS
BEGIN

	SET NOCOUNT ON;
	--����������������еĴ���
	DECLARE @rows INT,
		@rows_limit INT
		,@row_batch INT
		,@row_count INT
		,@date DATETIME

	SELECT
		@rows = 0,
		@rows_limit = (SELECT COUNT(*) FROM bank.Transactions_mf57), -- ����������¼������
		@row_batch = 1000,
		@row_count=@row_batch      -- ÿ�������ļ�¼��

--�ж������������е�С�ڵ�ǰʱ��ǰһ������ݶ������˴���
	WHILE  @row_count = @row_batch
		AND @rows < @rows_limit
		OR (SELECT MIN(Indate) FROM bank.Transactions_mf57 WHERE Indate<DATEADD(YEAR,-1,GETDATE())) IS NOT NULL
		BEGIN
			SELECT @date=(SELECT MIN(Indate) FROM bank.Transactions_mf57 WHERE Indate<DATEADD(YEAR,-1,GETDATE()))

			DECLARE @year DATETIME
					,@year_last DATETIME

			select @year=CONVERT(datetime,CONVERT(VARCHAR(4),DATEPART(YEAR,@date)))

			select @year_last=DATEADD(YEAR,1,@year)

			DECLARE @tablename VARCHAR(MAX),@create_sql VARCHAR(MAX),@Insert_sql VARCHAR(MAX)

			select @tablename='transcation_mf57_'+CONVERT(NCHAR(4),DATEPART(YEAR,@date))

			--�����ǰ���в����ڶ�Ӧ����ݹ鵵��
			IF NOT EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'['+@tablename+']')) 
				BEGIN
					SELECT @create_sql=N'CREATE TABLE '+ @tablename+'
										(		
											TransactionNumber			INT	IDENTITY(1,1)	NOT NULL	PRIMARY KEY
											,Card_ID					VARCHAR(50)			NOT NULL
											,TransactionType			NVARCHAR(2)			NOT NULL
											,Amount						DECIMAL(12,2)		NOT NULL
											,Indate						DATETIME			NOT NULL
											,TransactionStatus			BIT					NOT NULL
											,Reamarks					NVARCHAR(300)		NULL
											,LastEditDate				DATETIME			NOT NULL	DEFAULT GETDATE()
										)'

					EXEC(@create_sql);
							
						
				END	
		
			SELECT @insert_sql='DELETE TOP ('+CONVERT(VARCHAR ,@row_batch)+')
								FROM [bank].Transactions_mf57 
								OUTPUT DELETED.Card_ID,
										DELETED.TransactionType,
										DELETED.Amount,
										DELETED.Indate,
										DELETED.TransactionStatus,
										DELETED.Reamarks INTO '+@tablename+'
										(
											Card_ID
											,TransactionType
											,Amount
											,Indate
											,TransactionStatus
											,Reamarks
										)
								WHERE Indate<N'''+CONVERT(VARCHAR(50),DATEADD(YEAR,-1,GETDATE()))
									+''' AND Indate>'+N''''+CONVERT(VARCHAR(50),@year)
									+''' AND Indate <N'''+CONVERT(VARCHAR(50),@year_last)+''''
			EXEC(@insert_sql) 

			WAITFOR DELAY '00:00:10'

			SELECT @row_count=@@ROWCOUNT

			SELECT @rows=@rows+@row_count

			SELECT @returnvalue=@rows
		END
END



--insert into bank.Transactions_mf57 (Card_ID,TransactionType,Amount,Indate,TransactionStatus)
--select '123456789',N'֧��',500.00,'2015-5-6',1
--insert into bank.Transactions_mf57 (Card_ID,TransactionType,Amount,Indate,TransactionStatus)
--select '123456789',N'֧��',500.00,'2014-5-6',1
--insert into bank.Transactions_mf57 (Card_ID,TransactionType,Amount,Indate,TransactionStatus)
--select '123456789',N'֧��',500.00,'2015-5-8',1
--insert into bank.Transactions_mf57 (Card_ID,TransactionType,Amount,Indate,TransactionStatus)
--select '123456789',N'֧��',500.00,'2013-5-6',1
--insert into bank.Transactions_mf57 (Card_ID,TransactionType,Amount,Indate,TransactionStatus)
--select '123456789',N'֧��',500.00,'2014-5-10',1
--insert into bank.Transactions_mf57 (Card_ID,TransactionType,Amount,Indate,TransactionStatus)
--select '123456789',N'֧��',500.00,'2016-7-20',1
--insert into bank.Transactions_mf57 (Card_ID,TransactionType,Amount,Indate,TransactionStatus)
--select '123456789',N'֧��',500.00,'2016-7-30',1
--insert into bank.Transactions_mf57 (Card_ID,TransactionType,Amount,Indate,TransactionStatus)
--select '123456789',N'֧��',500.00,'2014-3-21',1