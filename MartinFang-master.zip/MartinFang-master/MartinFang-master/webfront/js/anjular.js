var app = angular.module("personapp", []);
app.controller("personcontrol", function ($scope, $http) {    
    var a=$http.get("./json/person.json").success(function(data,config,headers,status){
        data.forEach(function(person) {
           $scope.name=person.name ;
           $scope.Job=person.Job;
            $scope.Native=person.Native;
            $scope.Nation=person.Nation;
            $scope.sex=person.sex;
            $scope.Email=person.Email;
            $scope.phone=person.phone;
        }, data);
    })
})
app.controller("captioncontrol", function ($scope, $http) {    
    var a=$http.get("./json/caption.json").success(function(data,config,headers,status){
        data.forEach(function(caption) {
           $scope.title=caption.title ;
           $scope.date=caption.date;
            $scope.University=caption.University;
            $scope.major=caption.major;
            $scope.degree=caption.degree;
            $scope.U_M_D=caption.U_M_D;
            $scope.date_one=caption.date_one;
            $scope.describe_two=caption.describe_two;
            $scope.date_two=caption.date_two;
            $scope.describe_one=caption.describe_one;
            
        }, data);
    })
})
app.controller("projectcontrol", function ($scope, $http) {    
    var a=$http.get("./json/project.json").success(function(data,config,headers,status){
        data.forEach(function(project) {
           $scope.title_one=project.title_one ;
           $scope.describe_one=project.describe_one;
            $scope.item_one_one=project.item_one_one;
            $scope.item_one_three=project.item_one_three;
            $scope.item_one_four=project.item_one_four;
            $scope.title_two=project.title_two;
            $scope.describe_two=project.describe_two;
            $scope.item_one_two=project.item_one_two;
            $scope.item_two_one=project.item_two_one;
            $scope.item_two_two=project.item_two_two;
            
        }, data);
    })
})

app.controller("skillcontrol", function ($scope, $http) {    
    var a=$http.get("./json/skill.json").success(function(data,config,headers,status){
        data.forEach(function(skill) {
           $scope.skill_one=skill.skill_one ;
           $scope.skill_two=skill.skill_two;
            $scope.skill_three=skill.skill_three;
            $scope.skill_four=skill.skill_four;            
        }, data);
    })
})