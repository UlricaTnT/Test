
var action = $(".person");
var x
$(document).ready(function () {
    $("#li_person").click(function () {
        if (!action.is($(".person"))) {
            action = $(".person");
            transformX();
        }

    })
    $("#li_caption").click(function () {
        if (!action.is($(".caption"))) {
            action = $(".caption");
            transformX();
        }

    })
    $("#li_project").click(function () {
        if (!action.is($(".project"))) {
            action = $(".project");

            transformX();
        }
    })
    $("#li_skill").click(function () {
        if (!action.is($(".skill"))) {
            action = $(".skill");
            transformX();
        }
    })
    $("#btn_person").click(function () {
        if (!action.is($(".person"))) {
            action = $(".person");
            transformY();
        }
    })
    $("#btn_caption").click(function () {
        if (!action.is($(".caption"))) {
            action = $(".caption");
            transformY();
        }
    })
    $("#btn_project").click(function () {
        if (!action.is($(".project"))) {
            action = $(".project");

            transformY();
        }
    })
    $("#btn_skill").click(function () {
        if (!action.is($(".skill"))) {
            action = $(".skill");
            transformY();
        }
    })
})



var t;
var i = 0
var i2 = -180;
var op = 1;
var op2 = 0;
var transformX = function () {
    x = $(".action");

    action.css({
        "transform": "perspective(800px) rotateX(" + i2 + "deg)",
        "opacity": op2
    })
    x.css({
        "transform": "perspective(800px) rotateX(" + i + "deg)",
        "opacity": op
    })

    i -= 0.5;
    op -= 0.001;
    i2 -= 0.5;
    op2 += 0.001;
    if (i < -90)
        x.css({
            "display": "none"
        })
    if (i2 < -270)
        action.css({
            "display": "block"
        })
    if (i > -180) {
        t = setTimeout("transformX()", 0.000000001);
    }
    else {
        clearTimeout(t);
        x.css({
            "transform": "perspective(800px) rotateX(-180deg)",
            "opacity": 0
        })
        x.removeClass("action");
        action.css({
            "transform": "perspective(800px) rotateX(0deg)",
            "opacity": 1
        })
        action.addClass("action");
        i = 0;
        i2 = -180;
        op = 1;
        op2 = 0;

    }

}

var transformY = function () {
    var x = $(".action");
    action.css({
        "transform": "perspective(800px) rotateY(" + i2 + "deg)",
        "opacity": op2
    })
    x.css({
        "transform": "perspective(800px) rotateY(" + i + "deg)",
        "opacity": op
    })

    i -= 0.5;
    op -= 0.001;
    i2 -= 0.5;
    op2 += 0.001;
    if (i < -90)
        x.css({
            "display": "none"
        })
    if (i2 < -270)
        action.css({
            "display": "block"
        })
    if (i > -180) {
        t = setTimeout("transformY()", 0.000001);
    }
    else {
        clearTimeout(t);
        x.css({
            "transform": "perspective(800px) rotateY(-180deg)",
            "opacity": 0
        })
        x.removeClass("action");
        action.css({
            "transform": "perspective(800px) rotateY(0deg)",
            "opacity": 1
        })
        action.addClass("action");
        i = 0;
        i2 = -180;
        op = 1;
        op2 = 0;

    }

}