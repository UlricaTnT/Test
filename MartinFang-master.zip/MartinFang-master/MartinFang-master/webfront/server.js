const http = require("http");
var fr = require("fs");
var url = require("url")
 
function server_start(port) {
    http.createServer().listen(port)
}
function OnReaquest(request, response) {
    try {
        var type = request.headers['accept'];
 
            var pathname = "./" + url.parse(request.url).pathname;
            response.writeHead(200, {
                "Content-Type": type,
                "Access-Control-Allow-Origin": "localhost:8089"
            })
            var data = fr.readFileSync(pathname, "binary");
 
            //var data = fr.readFileSync(pathname, "utf-8");
            response.write(data,'binary');
            response.end();
            console.log("Ok");
        }
        // if(url.parse(request.url).pathname!="/favicon.ico"){
 
        //}
    catch (err) {
        console.log(err)
    }
}
 
http.createServer(OnReaquest).listen(8089);//