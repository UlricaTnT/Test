﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.Intern.Training.OOP.Exercise
{
    public class ConsoleLogger : ILogger
    {
        public void Debug(string message)
        {
            Console.WriteLine("Debug: " + message+" " + DateTime.Now.ToLocalTime().ToString());
        }

        public void Error(string message)
        {
            Console.WriteLine("Error:" + message +" "+ DateTime.Now.ToLocalTime().ToString());
        }

        public void Info(string message)
        {
            Console.WriteLine("Info:" + message+" " + DateTime.Now.ToLocalTime().ToString());
        }

        public void Warning(string message)
        {
            Console.WriteLine("Warning:" + message+" " + DateTime.Now.ToLocalTime().ToString());
        }
    }
}
