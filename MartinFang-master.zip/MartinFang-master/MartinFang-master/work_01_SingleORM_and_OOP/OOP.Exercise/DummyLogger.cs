﻿using System;
using System.IO;
using System.Configuration;
using System.Xml.Serialization;

namespace Newegg.Intern.Training.OOP.Exercise
{

    public class DummyLogger : ILogger
    {

        private IFileSave _ifilesave;

        public DummyLogger(IFileSave ifilesave)
        {
            _ifilesave = ifilesave;
        }

        public void Info(string message)
        {
            string writemessage = "(Info) " + message;
            _ifilesave.write(writemessage);
        }

        public void Debug(string message)
        {
            string writemessage = "(Debug) " + message;
            _ifilesave.write(writemessage);
        }

        public void Warning(string message)
        {
            string writemessage = "(Warning) " + message ;
            _ifilesave.write(writemessage);
        }

        public void Error(string message)
        {
            string writemessage = "(Error) " + message;
            _ifilesave.write(writemessage);
        }
    }   
}
