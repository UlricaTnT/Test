﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.Intern.Training.OOP.Exercise
{
    public interface IFileSave
    {
         void write(string message);//写文件
    }
}
