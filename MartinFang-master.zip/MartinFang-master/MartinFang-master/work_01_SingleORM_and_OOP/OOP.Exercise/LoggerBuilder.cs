﻿using System;
using System.Configuration;
using NUnit.Framework;
using System.Reflection;
using NUnit.Framework;

namespace Newegg.Intern.Training.OOP.Exercise
{
    [TestFixture]
    public static class LoggerBuilder
    {
        private static object[] Getparameter()
        {
            var type = ConfigurationManager.AppSettings["type"];

            var filepath = ConfigurationManager.AppSettings["Path"];

            if (type == "txt")
            {
                return new object[] { new TxtSave(filepath) };
            }
            else if (type == "xml")
            {
                return new object[] { new XmlSave(filepath) };
            }
            return new object[] { };
        }

        [Test]
        public static ILogger Build()
        {
            var config = ConfigurationManager.AppSettings["Logger"];//获取到配置文件的值\


            Assembly assembly = Assembly.GetExecutingAssembly();



            object logger = assembly.CreateInstance(config, true, BindingFlags.Default, null, Getparameter(), null, null);

            if (logger != null)
                return (ILogger)logger;
            else
            {
                Console.WriteLine("配置文件错误");
                return new DefaultLogger();
            }

        }

    }
}
