﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Newegg.Intern.Training.OOP.Exercise
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var logger = LoggerBuilder.Build();
            logger.Info("message info");
            logger.Error("message Error");
            logger.Debug("message Debug");
            logger.Warning("message Warning");
            Console.Write("Press any key to quit...");
            Console.ReadKey();
        }
    }
}
