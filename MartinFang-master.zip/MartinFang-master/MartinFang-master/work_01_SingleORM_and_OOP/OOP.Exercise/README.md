# 第二次的作业的代码的解释

首先我们定义了两个类和一个接口
DummyLogger、ConsoleLogger 和 ILogger接口，同时两个类继承了我们的ILogger接口

    public static ILogger Build()
        {

            var config = ConfigurationManager.AppSettings["Logger"];//获取到配置文件的值

            Assembly assembly = Assembly.GetExecutingAssembly();

            object logger=assembly.CreateInstance(config);

            return (ILogger)logger;

            // TODO: implement this method.
            // Read configuration from app.config
            // determine the logger type, and create instance 
            // of the configured logger.
        }


首先我们先从配置文件中读取到我们想要的值

    var config = ConfigurationManager.AppSettings["Logger"];//获取到配置文件的值

利用反射获取当前程序的运行集并且按照我们获得的值创建一个实例化对象

    Assembly assembly = Assembly.GetExecutingAssembly();

            object logger=assembly.CreateInstance(config);


完整实现代码最后我们返回了一个ilogger的接口对象，在这里我们为什么返回这样的一个对象？因为在我们程序没有运行的时候我们是无法知道到底是输出在我们的控制台还是我们的日志文件中

在这里我和Lewis刚刚在讨论到底是该配置文件来决定输出到控制台还是配置文件还是修改build方法的返回值来修改，在我们里我觉得还是修改配置文件来的好一点，如果我们的程序在不同的机器上面运行，一个机器想要将配置文件控制台，一个机器想要输出到配置文件，我们就仅仅需要修改配置iwenjian中的两行，就可以决定输出方式。而且在程序部署过后我们是没有办法来访问方法内部的。

最后我们在config文件中定义这两行数据

    <?xml version="1.0" encoding="utf-8" ?>
    <configuration>
        <!--输出到log日志文件中-->
         <!--<appSettings>
            <add key="Logger" value="Newegg.Intern.Training.OOP.Exercise.DummyLogger"/>
            <add key="Path" value="logger.txt"/>
        </appSettings>-->
        <!--输出到控制台-->
        <appSettings>
           <add key="Logger" value="Newegg.Intern.Training.OOP.Exercise.ConsoleLogger"/>
        </appSettings>
    </configuration>

在配置文件中的两行数据就决定了我们的输出方式

## 修改
* 将输出到日志文件中添加了两个类其中包含两个输出到txt文件和xml文件
通过DummyLogger类的构造函数中注入依赖来决定其输出方式
* 在loggerBuikder中新增函数

        private static object[] Getparameter()
        {
            var type = ConfigurationManager.AppSettings["type"];

            var filepath = ConfigurationManager.AppSettings["Path"];

            if (type == "txt")
            {
                return new object[] {new TxtSave(filepath) };
            }
            else if (type == "xml")
            {
                return new object[] { new XmlSave(filepath) };
            }
            return new object[] { };
        }
    通过config文件中的type决定输出类型
