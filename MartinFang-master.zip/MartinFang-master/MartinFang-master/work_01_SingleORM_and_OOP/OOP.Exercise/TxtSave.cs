﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Newegg.Intern.Training.OOP.Exercise
{
    public class TxtSave : IFileSave
    {
        private static string _filepath;


        public TxtSave(string filepath)
        {
            _filepath = filepath;
        }

        public void write(string message)
        {
            using (StreamWriter fs = new StreamWriter(_filepath, true))
            {
                fs.WriteLine(message+" "+DateTime.Now);
            }

        }
    }
}
