﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;
using NUnit.Framework;

namespace Newegg.Intern.Training.OOP.Exercise
{
    [TestFixture]
    public class XmlSave : IFileSave
    {
        private readonly string _filepath;
        public XmlSave(string filepath)
        {
            _filepath = filepath;
        }
        [Test]
        public void write(string message)
        {
            if (File.Exists(_filepath))
            {
                XmlDocument xml = new XmlDocument();

                xml.Load(_filepath);

                XmlNodeList date = xml.SelectNodes("/log/date/.");

                foreach (XmlNode node in date)
                {
                    if (node.Attributes["value"].Value == DateTime.Now.ToShortDateString())
                    {
                        XmlElement xe = xml.CreateElement("information");
                        xe.SetAttribute("message", message);
                        xe.SetAttribute("time", DateTime.Now.ToShortTimeString());

                        node.AppendChild(xe);
                    }
                    else
                    {
                        XmlElement datetime = xml.CreateElement("date");
                        datetime.SetAttribute("value", DateTime.Today.ToShortDateString());

                        XmlElement xe = xml.CreateElement("information");
                        xe.SetAttribute("message", message);
                        xe.SetAttribute("time", DateTime.Now.ToShortTimeString());

                        datetime.AppendChild(xe);

                        xml.AppendChild(datetime);
                    }
                }

                xml.Save(_filepath);


            }
            else
            {
                XmlDocument xml = new XmlDocument();


                XmlElement date = xml.CreateElement("date");
                date.SetAttribute("value", DateTime.Today.ToShortDateString());

                XmlElement xe = xml.CreateElement("information");
                xe.SetAttribute("message", message);
                xe.SetAttribute("time", DateTime.Now.ToShortTimeString());

                date.AppendChild(xe);               

                xml.AppendChild(date);

                xml.Save(_filepath);
            }
            

            
        }
    }
}
