## 项目目录

* work_01_simpleOrm为第一次的作业

    * About_SingleORM.md 是我对代码的一些理解

    * work_01_simpleOrm.sln 为解决方案
* OOP.exercise 

    * 有一些我对代码的理解和遇到的一些问题

    * OOP.exercise.sln 解决方案

## 存在的问题
 
 以字符串作为查询条件的注入式攻击问题

 select * from tablename where 字符串

 这样如果以这样的方式来进行数据库的查询的话会存在明显的sql漏洞。
 经过Mark的解答之后我将我的查询方法变成了

    List<TEntity> Query<TEntity>(string condition,List<SqlParameter> pa) where TEntity : class, new();

多加了一个参数列表

    List<SqlParameter> list = new List<SqlParameter>()
            {
                new SqlParameter("@p1",5),
                new SqlParameter("@p2",9),
                new SqlParameter("@p3",6)
            };

            da.Query<MartinTable>("ID between @p1 and @p2 and ID<>@p3", list);

最后以这样的方式来完成了查询，避免了sql漏洞

## 项目收获

在一整周的学习当中我最大的收获就是学会了反射的基本概念，在学习的过程中我发现反射真的很好用，因为通过反射我们有了很大的操作空间，不用在编写代码的时候就对实体进行定义，而是在运行的过程当中通过我们在调用的时候来决定类型，利用反射和泛型搭配起来的话能够提高代码的重用性。

同时我在观看小伙伴们的代码和BLOG的时候也能从中发现我自己的问题，像sql注入式攻击，利用SqlParameter来防止攻击等等