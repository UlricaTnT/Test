##  这次的第一个作业是完成一个小型的ORM的框架，下面我简单的说明一下我自己写的代码

1. 首先我按照 Mark给的代码 完成了sqlhelper的类和ISqlHelper的接口，和IDataAccessor接口
2. 然后我定义了2个特性类分别是TableAttribute、ColumnAttribute两个特性类
```
//其中包含Tablename的属性来确定需要执行的数据库操作的表名
 [AttributeUsage(AttributeTargets.Class,AllowMultiple = false,Inherited = true)]
    public class TableAttribute : System.Attribute
    {
        public string tableName { get; set; }

        public TableAttribute(string name)
        {
            tableName = name;
        }

    }

```

```
    /// <summary>
    /// 实体中每个属性的一系列与数据库相关的特性，是否为主键、是否为空、其数据类型、数据大小，是否自增
    /// </summary>
    [AttributeUsage(AttributeTargets.Property,AllowMultiple = false,Inherited = true)]
    public class ColumnAttribute : System.Attribute
    {
        public bool IsPrimaryKey { get; set; }

        public string Name { get; set; }

        public string DataType { get; set; }

        public int Size { get; set; }

        public bool IsNull{get;set;}

        public bool identity { get; set; }

        public ColumnAttribute(string name)
        {
            Name = name;
        }

        public static ColumnAttribute GetDataFieldAttribute(PropertyInfo property)
        {
            object[] oArr = property.GetCustomAttributes(true);
            for (int i = 0; i < oArr.Length; i++)
            {
                if (oArr[i] is ColumnAttribute)
                    return (ColumnAttribute)oArr[i];
            }
            return null;
        }
    }
```
这两个特性在后面使用过程中起到了至关重要的作用

3. 构建实体类 
```
 [Table("dbo.MartinTest")]
    public class Martin
    {

        private int _ID;

        [Column("ID", DataType = "Int", IsPrimaryKey = true,identity =true)]
        public int ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        private string _Name;

        [Column("Name", DataType = "NVarChar", Size = 50)]
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
    }
```
这是实体类中两个属性，我们可以看到在这里我们使用了刚刚定义到的特性类，详细的说明了每一个属性的某些特性

4. 最后我们来实现IdataAccessor中的方法， 这里我们以添加实体CreatEntity为例进行说明
```
 string TableName = ((TableAttribute)entity.GetType().GetCustomAttributes(true)[0]).tableName;//获取表名
```
这一行代码就是特性的作用，我们利用反射回去到实体的类型，然后获取其特性值获得表的名字

```
PropertyInfo[] TypeProperty = entity.GetType().GetProperties();//获取到所有的属性信息
```
利用反射 获取实体类型的所有属性

```
List<SqlParameter> parameter = new List<SqlParameter>();//参数列表

            StringBuilder sql = new StringBuilder();

            sql.Append(" insert into "+TableName+" ( ");

            for (int i=0;i<TypeProperty.Length;i++)
            {
                PropertyInfo pre = TypeProperty[i];

                ColumnAttribute col = ColumnAttribute.GetDataFieldAttribute(pre);

                SqlParameter sqlp = new SqlParameter();

                if (!(pre.GetValue(entity, null) == null)&& !col.identity)
                {
                    if (col.Size != 0)
                        sqlp = new SqlParameter("@" + col.Name, VType_to_DbType.turn(col.DataType), col.Size) { Value = pre.GetValue(entity, null) };
                    else
                        sqlp = new SqlParameter("@" + col.Name, VType_to_DbType.turn(col.DataType)) { Value = pre.GetValue(entity, null) };

                    parameter.Add(sqlp);

                    sql.Append(col.Name + ",");
                }
            }

            sql.Remove(sql.Length - 1, 1);
            sql.Append(" ) ");

            sql.Append(" values ( ");
            foreach (var pre in TypeProperty)
            {
                ColumnAttribute col = ColumnAttribute.GetDataFieldAttribute(pre);
                if (!(pre.GetValue(entity, null) == null) && !col.identity)
                    sql.Append("@" + col.Name + ",");

            }
            sql.Remove(sql.Length - 1, 1);
            sql.Append(" ) SELECT SCOPE_IDENTITY() ");
```
在上面的代码中我们可以看到我们使用了大量的篇幅来创造数据库语句和参数列表，为什么在这里我要这么做，我是想让这一个函数能够运用于更加多的数据库表，为每一个表来定义不同的参数列表和数据库操作语句。

最后
```
using (var conn = SqlHelper.ISqlHelper.GetConnection())
            {


                var insertedId = SqlHelper.ISqlHelper.ExecuteScalar<int>(conn, sql.ToString(),
                   parameter);

                Console.WriteLine("New record has been inserted, id {0}.", insertedId);
                return insertedId;
            }
```

这一段代码块就是借助SqlHelper类来实现与数据库进行交互并对数据库进行操作；

我们来看最后的测试结果
我们首先先定义另外一个类，映射不同的数据库的表我们看能不能正常插入
```
///MartinTable 表，对应dbo.MartinTable表
    [Table("dbo.MartinTable")]
    public class MartinTable
    {

        private int _ID;
        [Column("ID",DataType ="Int",IsPrimaryKey =true,identity =true)]
        public  int ID
        {
            get { return _ID;}
            set { _ID = value;}
        }

        private string _Name;
        [Column("Name",DataType ="VarChar",Size =50)]
        public string Name
        {
            get { return _Name;}
            set {_Name=value; }
        }

        private string _Phone;
        [Column("Phone", DataType = "VarChar", Size = 50,IsNull =true)]
        public string Phone
        {
            get {return _Phone; }
            set { _Phone = value; }
        }
    }
```

测试代码

定义了两个不同的实体对象，分别调用DataAccessor类中的Creat方法

```
 private static  DataAccessor da = new DataAccessor();
        [Test]
        public void CreatEntityTest()
        {
            

            MartinTable Mtable = new MartinTable();

            Martin martin = new Martin();

            martin.InDate = DateTime.Now;
            martin.InUser = "test";
            martin.Name = "Martin";
            da.Create(martin);

            Mtable.Name = "Martin";
            Mtable.Phone = "023-123456";

            da.Create(Mtable);
        }
```

测试结果

![](picture/test.PNG)我们看到我们成功的插入了两条语句，下面让我们来看看我们数据库中是否真的存在这两条

测试代码

     [Test]
        public void QueryTest()
        {
            da.Query<Martin>("ID=12");
            da.Query<MartinTable>("ID=5");

        }

测试结果

![](picture/test2.png)

我们可以看到我们从数据库中查找到了两条数据。这样我们就达到了只使用一个操作函数同时对不同的实体类型进行操作。
