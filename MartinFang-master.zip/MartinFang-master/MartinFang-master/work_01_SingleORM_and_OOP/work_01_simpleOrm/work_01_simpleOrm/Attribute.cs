﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace work_01_simpleOrm
{
    [AttributeUsage(AttributeTargets.Class,AllowMultiple = false,Inherited = true)]
    public class TableAttribute : System.Attribute
    {
        public string tableName { get; set; }

        public TableAttribute(string name)
        {
            tableName = name;
        }

    }

    /// <summary>
    /// 实体中每个属性的一系列与数据库相关的特性，是否为主键、是否为空、其数据类型、数据大小，是否自增
    /// </summary>
    [AttributeUsage(AttributeTargets.Property,AllowMultiple = false,Inherited = true)]
    public class ColumnAttribute : System.Attribute
    {
        public bool IsPrimaryKey { get; set; }

        public string Name { get; set; }

        public string DataType { get; set; }

        public int Size { get; set; }

        public bool IsNull{get;set;}

        public bool identity { get; set; }

        public ColumnAttribute(string name)
        {
            Name = name;
        }

        public static ColumnAttribute GetDataFieldAttribute(PropertyInfo property)
        {
            object[] oArr = property.GetCustomAttributes(true);
            for (int i = 0; i < oArr.Length; i++)
            {
                if (oArr[i] is ColumnAttribute)
                    return (ColumnAttribute)oArr[i];
            }
            return null;
        }
    }
}
