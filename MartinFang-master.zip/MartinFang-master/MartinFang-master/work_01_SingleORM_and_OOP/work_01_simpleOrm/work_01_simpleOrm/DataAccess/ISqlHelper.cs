﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace work_01_simpleOrm.DataAccess
{
    public interface ISqlHelper
    {
        /// <summary>
        /// 获取数据库连接
        /// </summary>
        /// <returns> 返回SqlConnection 对象 </returns>
        SqlConnection GetConnection();

        SqlConnection GetConnection(string connectionString);

        SqlDataReader ExecuteQuery(SqlConnection conn, string sql, List<SqlParameter> parameters);


        int ExecuteNonQuery(string sql, List<SqlParameter> parameters);

        

        int ExecuteNonQuery(SqlConnection conn, string sql, List<SqlParameter> parameters);

        T ExecuteScalar<T>(string sql, List<SqlParameter> parameters);

        T ExecuteScalar<T>(SqlConnection conn, string sql, List<SqlParameter> parameters);

    }
}
