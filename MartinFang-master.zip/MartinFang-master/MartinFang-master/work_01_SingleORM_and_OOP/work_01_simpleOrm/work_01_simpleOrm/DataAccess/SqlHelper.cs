﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Threading;

namespace work_01_simpleOrm.DataAccess
{
    public class SqlHelper : ISqlHelper
    {
        private const string ConnectionStringCfgKey = "ConnectionString";

        private SqlHelper() { }

        public  static ISqlHelper Isqlhelper;

        private static readonly Lazy<SqlHelper> LazyInstance = new Lazy<SqlHelper>(
            () => new SqlHelper(), LazyThreadSafetyMode.ExecutionAndPublication);

        public static void SetInstance(ISqlHelper fakeSqlHelper)
        {
            Isqlhelper = fakeSqlHelper;
        }

        public static void ResetInstance()
        {
            Isqlhelper = null;
        }

        public static ISqlHelper ISqlHelper
        {
            get
            {
                if (null != Isqlhelper) return Isqlhelper;
                return LazyInstance.Value;
            }
        }



        public SqlHelper(ISqlHelper isqlhelper,string connectionstring)
        {
            
        }

        public SqlHelper(ISqlHelper isqlhelper)
        {
        }


        /// <summary>
        /// 确认数据库连接打开 
        /// </summary>
        /// <param name="conn">SqlConnection对象</param>
        private void EnsureConnectionOpen(DbConnection conn)
        {
            if (conn.State == ConnectionState.Open) return;

            conn.Open();

        }

        /// <summary>
        /// 不带参数列表构建sqlcommand对象
        /// </summary>
        /// <param name="conn"> Sqconnection 对象 </param>
        /// <param name="sql"> 数据库语句 </param>
        /// <returns>sqlcommand对象</returns>
        private SqlCommand BuildCommand(SqlConnection conn, string sql)
        {
            var cmd = new SqlCommand(sql, conn);

            return cmd;
        }

        /// <summary>
        /// 带参数列表构建sqlcommand对象
        /// </summary>
        /// <param name="conn">sqlconnection对象</param>
        /// <param name="sql">数据库查询语句</param>
        /// <param name="parameters">参数列表</param>
        /// <returns></returns>
        private SqlCommand BuildCommand(SqlConnection conn, string sql,
            List<SqlParameter> parameters)
        {
            var cmd = new SqlCommand(sql, conn);

            if (null != parameters)
            {
                parameters.ForEach(p => cmd.Parameters.Add(p));
            }
            return cmd;
        }

        /// <summary>
        /// 带参数列表执行数据库惭怍并返回收影响的条数，无sqlconnection对象
        /// </summary>
        /// <param name="sql">数据库操作语句</param>
        /// <param name="parameters"> 参数列表 </param>
        /// <returns></returns>
        public int ExecuteNonQuery(string sql, List<SqlParameter> parameters)
        {
            using (var conn = GetConnection())
            {
                return ExecuteNonQuery(conn, sql, parameters);
            }
        }


        /// <summary>
        /// 带参数列表执行数据库操作并返回受影响的条数,有数据库连接
        /// </summary>
        /// <param name="conn">Sqlconnection 对象</param>
        /// <param name="sql">数据库语句</param>
        /// <param name="parameters">参数列表</param>
        /// <returns></returns>
        public int ExecuteNonQuery(SqlConnection conn, string sql, List<SqlParameter> parameters)
        {
            var cmd = BuildCommand(conn, sql, parameters);

            EnsureConnectionOpen(conn);

            return cmd.ExecuteNonQuery();
        }


        /// <summary>
        /// 带参数列表返回一个向前只读的datareader
        /// </summary>
        /// <param name="conn"> sqlconnection 对象</param>
        /// <param name="sql">数据库执行语句</param>
        /// <param name="parameters">参数列表</param>
        /// <returns></returns>
        public SqlDataReader ExecuteQuery(SqlConnection conn, string sql, List<SqlParameter> parameters)
        {
            var cmd = BuildCommand(conn, sql, parameters);

            EnsureConnectionOpen(conn);

            return cmd.ExecuteReader();
        }


        public T ExecuteScalar<T>(string sql, List<SqlParameter> parameters)
        {
            using (var conn = GetConnection())
            {
                return ExecuteScalar<T>(conn, sql, parameters);
            }
        }

        public T ExecuteScalar<T>(SqlConnection conn, string sql, List<SqlParameter> parameters)
        {
            var cmd = BuildCommand(conn, sql, parameters);

            EnsureConnectionOpen(conn);

            var result = cmd.ExecuteScalar();//返回数据库第一行

            if (null == result || DBNull.Value == result)
            {
                return default(T);//返回泛型的默认值
            }

            return (T)Convert.ChangeType(result, typeof(T));//将最后的查询结果返回为泛型的类型
        }

        /// <summary>
        /// 使用默认的连接字符串
        /// </summary>
        /// <returns> SqlConnertion 对象 </returns>
        public SqlConnection GetConnection()
        {
            return GetConnection(null);
        }

        /// <summary>
        /// 获取到传入的连接字符串
        /// </summary>
        /// <param name="connectionString"> 连接字符串 </param>
        /// <returns> SqlConnertion 对象 </returns>
        public SqlConnection GetConnection(string connectionString)
        {
            if (string.IsNullOrWhiteSpace(connectionString))
            {
                connectionString = ConfigurationManager.AppSettings.Get(ConnectionStringCfgKey);
            }

            if (string.IsNullOrWhiteSpace(connectionString))
            {
                throw new ArgumentException(
                    "Connection string must be specified " +
                    "either from parameter or App.config file.");
            }

            return new SqlConnection(connectionString);

        }

        
    }
}
