﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using work_01_simpleOrm.DataAccess;
using System.Reflection;
using System.Data;
using System.Text;


namespace work_01_simpleOrm
{
    public class DataAccessor : IDataAccessor
    {

        public DataAccessor()
        {

        }

        public DataAccessor(string connectionString)
        {
            // TODO: Implement this constructor
        }

        public int Create<TEntity>(TEntity entity) where TEntity : class
        {
            string TableName = ((TableAttribute)entity.GetType().GetCustomAttributes(true)[0]).tableName;//获取表名

            PropertyInfo[] TypeProperty = entity.GetType().GetProperties();//获取到所有的属性信息

            List<SqlParameter> parameter = new List<SqlParameter>();//参数列表

            StringBuilder sql = new StringBuilder();//初始化数据库操作语句

            sql.Append(" insert into " + TableName + " ( ");

            for (int i = 0; i < TypeProperty.Length; i++)
            {
                PropertyInfo pre = TypeProperty[i];//获取每一个属性的信息

                ColumnAttribute col = ColumnAttribute.GetDataFieldAttribute(pre);//获取信息的特性值

                SqlParameter sqlp = new SqlParameter();

                if (!(pre.GetValue(entity, null) == null) && !col.identity)//判断属性的值是否为空，并且是否自增
                {
                    if (col.Size != 0)//如果属性的数据大小不为0，有些数据类型需要大小，有些则不需要
                        sqlp = new SqlParameter("@" + col.Name, VType_to_DbType.turn(col.DataType), col.Size) { Value = pre.GetValue(entity, null) };
                    else
                        sqlp = new SqlParameter("@" + col.Name, VType_to_DbType.turn(col.DataType)) { Value = pre.GetValue(entity, null) };

                    parameter.Add(sqlp);//将参数添加至参数列表

                    sql.Append(col.Name + ",");
                }
            }

            sql.Remove(sql.Length - 1, 1);
            sql.Append(" ) ");

            sql.Append(" values ( ");
            foreach (var pre in TypeProperty)
            {
                ColumnAttribute col = ColumnAttribute.GetDataFieldAttribute(pre);
                if (!(pre.GetValue(entity, null) == null) && !col.identity)
                    sql.Append("@" + col.Name + ",");

            }
            sql.Remove(sql.Length - 1, 1);
            sql.Append(" ) SELECT SCOPE_IDENTITY() ");

            using (var conn = SqlHelper.ISqlHelper.GetConnection())
            {


                var insertedId = SqlHelper.ISqlHelper.ExecuteScalar<int>(conn, sql.ToString(),
                   parameter);

                Console.WriteLine("New record has been inserted, id {0}.", insertedId);
                return insertedId;
            }

        }

        public int Delete<TEntity>(TEntity entity) where TEntity : class
        {
            Type t = entity.GetType();

            PropertyInfo[] properinfo = t.GetProperties();


            using (var con = SqlHelper.ISqlHelper.GetConnection())
            {
                string TableName = ((TableAttribute)entity.GetType().GetCustomAttributes(true)[0]).tableName;

                foreach (var proper in properinfo)
                {

                    ColumnAttribute col = ColumnAttribute.GetDataFieldAttribute(proper);

                    if (col.IsPrimaryKey)
                    {
                        var rowEffected = SqlHelper.ISqlHelper.ExecuteNonQuery(con,
                        "delete " + TableName + " where " + col.Name + "=@" + col.Name,
                        new List<SqlParameter>
                        {
                            new SqlParameter("@"+col.Name, VType_to_DbType.turn(col.DataType))
                            {
                                Value = t.GetProperty(col.Name).GetValue(entity, null)}
                            }
                        );

                        if (rowEffected == 1)
                        {
                            Console.WriteLine("Delete OK");
                        }
                        else
                        {
                            Console.WriteLine("There are no entity");
                        }
                        return rowEffected;
                    }

                }
                return -1;
            }
        }

        public List<TEntity> Query<TEntity>(string condition, List<SqlParameter> pa) where TEntity : class, new()
        {
            using (var conn = SqlHelper.ISqlHelper.GetConnection())
            {

                TEntity entity = new TEntity();

                string TableName = ((TableAttribute)entity.GetType().GetCustomAttributes(true)[0]).tableName;

                var reader = SqlHelper.ISqlHelper.ExecuteQuery(conn,
                    "SELECT * FROM "
                    + TableName
                    + " WITH(NOLOCK) where "+condition,
                    pa

                   );

                List<TEntity> list = new List<TEntity>();

                while (reader.Read())
                {

                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        System.Reflection.PropertyInfo propertyInfo = entity.GetType().GetProperty(reader.GetName(i));

                        if (propertyInfo != null)
                        {
                            if (reader.GetValue(i) != DBNull.Value)
                            {
                                if (propertyInfo.PropertyType.IsEnum)
                                {
                                    propertyInfo.SetValue(entity, Enum.ToObject(propertyInfo.PropertyType, reader.GetValue(i)), null);
                                }
                                else
                                {
                                    propertyInfo.SetValue(entity, reader.GetValue(i), null);
                                }
                            }

                            ColumnAttribute sol = ColumnAttribute.GetDataFieldAttribute(propertyInfo);

                            if (sol.IsPrimaryKey)
                                Console.WriteLine(sol.Name + (" Key (Type:") + sol.DataType + ")->" + reader.GetValue(i));
                            else
                                Console.WriteLine(sol.Name + ("(Type:") + sol.DataType + ")->" + reader.GetValue(i));
                        }

                    }
                    list.Add(entity);
                }
                return list;
            }
        }


        public int Update<TEntity>(TEntity entity) where TEntity : class
        {

            string TableName = ((TableAttribute)entity.GetType().GetCustomAttributes(true)[0]).tableName;

            PropertyInfo[] TypeProperty = entity.GetType().GetProperties();//获取到所有的属性信息

            List<SqlParameter> parameter = new List<SqlParameter>();

            StringBuilder sql = new StringBuilder();

            sql.Append(" UPDATE " + TableName + " SET ");

            string wherecondition = string.Empty;

            foreach (var pre in TypeProperty)
            {
                ColumnAttribute col = ColumnAttribute.GetDataFieldAttribute(pre);

                SqlParameter sqlp = new SqlParameter();


                if (!(pre.GetValue(entity, null) == null))
                {
                    if (col.IsPrimaryKey)
                        wherecondition = " where " + col.Name + " =@" + col.Name;
                    else
                        sql.Append(col.Name + "=@" + col.Name + ",");


                    if (col.Size != 0)
                        sqlp = new SqlParameter("@" + col.Name, VType_to_DbType.turn(col.DataType), col.Size) { Value = pre.GetValue(entity, null) };
                    else
                        sqlp = new SqlParameter("@" + col.Name, VType_to_DbType.turn(col.DataType)) { Value = pre.GetValue(entity, null) };

                    parameter.Add(sqlp);
                }


            }

            sql.Remove(sql.Length - 1, 1);

            sql.Append(wherecondition);

            using (var conn = SqlHelper.ISqlHelper.GetConnection())
            {


                var insertedId = SqlHelper.ISqlHelper.ExecuteScalar<int>(conn, sql.ToString(),
                   parameter);

                Console.WriteLine("Update OK");
                return insertedId;
            }
        }
    }
}
