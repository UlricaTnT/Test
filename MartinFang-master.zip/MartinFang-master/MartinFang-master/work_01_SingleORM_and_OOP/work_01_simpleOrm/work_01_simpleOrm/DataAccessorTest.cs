﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using System.Data.SqlClient;


namespace work_01_simpleOrm
{
    [TestFixture]
    public class DataAccessorTest
   {
       private static  DataAccessor da = new DataAccessor();
        [Test]
        public void CreatEntityTest()
        {
            

            MartinTable Mtable = new MartinTable();

            //Martin martin = new Martin();

            //martin.InDate = DateTime.Now;
            //martin.InUser = "test";
            //martin.Name = "Martin";
            //da.Create(martin);

            Mtable.Name = "Martin";
            Mtable.Phone = "x' or '1'='1';Drop table MartinTable";

            da.Create(Mtable);
        }


        [Test]
        public void QueryTest()
        {
            List<SqlParameter> list = new List<SqlParameter>()
            {
                new SqlParameter("@p1",5),
                new SqlParameter("@p2",9),
                new SqlParameter("@p3",6)
            };

            da.Query<MartinTable>("ID between @p1 and @p2 and ID<>@p3", list);
            
            //da.Query<MartinTable>("ID=5");
                

        }

        [Test]
        public void DeleteEntity()
        {
           List<MartinTable> DeletList=da.Query<MartinTable>("ID='x' OR '1'='1' --'");

            foreach (var deleelement in DeletList)
            {
                da.Delete(deleelement);
            }
        }

        [Test]
        public void UpdateEntity()
        {
            List<Martin> UpdateList = da.Query<Martin>("Name='Martin'");

            foreach (var updateelement in UpdateList)
            {
                updateelement.LastEditDate = DateTime.Now;
                updateelement.LastEditUser = "Martin_01";
                da.Update(updateelement);
            }
        }

        [Test]
        public void test()
        {
            List<SqlParameter> a = new List<SqlParameter>()
            {
                new SqlParameter("@name", System.Data.SqlDbType.VarChar) { Value = "123" }
            };
            SqlConnection conn = new SqlConnection();
            SqlCommand com = new SqlCommand("select * form tb where name=@name", conn);
            com.Parameters.Add(a[0]);

        
        }



    }
}
