﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace work_01_simpleOrm
{
    public interface IDataAccessor
    {

        List<TEntity> Query<TEntity>(string condition,List<SqlParameter> pa) where TEntity : class, new();

        int Create<TEntity>(TEntity entity) where TEntity : class;

        int Update<TEntity>(TEntity entity) where TEntity : class;

        int Delete<TEntity>(TEntity entity) where TEntity : class;
    }
}
