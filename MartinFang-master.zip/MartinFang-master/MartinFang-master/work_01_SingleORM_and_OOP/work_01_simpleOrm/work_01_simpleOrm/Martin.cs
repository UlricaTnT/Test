﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace work_01_simpleOrm
{
    [Table("dbo.MartinTestTable")]
    public class Martin
    {

        private int _ID;

        [Column("ID", DataType = "Int", IsPrimaryKey = true,identity =true)]
        public int ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        private string _Name;

        [Column("Name", DataType = "NVarChar", Size = 50)]
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        private DateTime _InDate;

        [Column("InDate", DataType = "DateTime")]
        public DateTime InDate
        {
            get { return _InDate; }
            set { _InDate = value; }
        }

        private string _InUser;

        [Column("InUser", DataType = "VarChar", Size = 15)]
        public string InUser
        {
            get { return _InUser; }
            set { _InUser = value; }
        }

        private DateTime? _LastEditDate;

        [Column("LastEditDate", DataType = "DateTime", IsNull =true)]
        public DateTime? LastEditDate
        {
            get { return _LastEditDate; }
            set { _LastEditDate = value; }
        }

        private string _LastEditUser;

        [Column("LastEditUser", DataType = "VarChar", Size = 50,IsNull =true)]
        public string LastEditUser
        {
            get { return _LastEditUser; }
            set { _LastEditUser = value; }
        }



    }
}
