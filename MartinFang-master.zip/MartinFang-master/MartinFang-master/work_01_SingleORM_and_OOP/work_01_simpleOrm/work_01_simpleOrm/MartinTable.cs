﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace work_01_simpleOrm
{
    [Table("dbo.MartinTable")]
    public class MartinTable
    {

        private int _ID;
        [Column("ID",DataType ="Int",IsPrimaryKey =true,identity =true)]
        public  int ID
        {
            get { return _ID;}
            set { _ID = value;}
        }

        private string _Name;
        [Column("Name",DataType ="VarChar",Size =50)]
        public string Name
        {
            get { return _Name;}
            set {_Name=value; }
        }

        private string _Phone;
        [Column("Phone", DataType = "VarChar", Size = 50,IsNull =true)]
        public string Phone
        {
            get {return _Phone; }
            set { _Phone = value; }
        }
    }
}
