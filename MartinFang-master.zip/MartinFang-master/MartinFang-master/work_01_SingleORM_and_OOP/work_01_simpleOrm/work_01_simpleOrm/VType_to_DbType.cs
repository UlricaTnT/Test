﻿using System;
using System.Collections.Generic;
using System.Data;

namespace work_01_simpleOrm
{
    class VType_to_DbType
    {
        public static SqlDbType turn(string DataType, int size = 0)
        {
            switch (DataType)
            {
                case "BigInt":
                    return SqlDbType.BigInt;

                case "Binary":
                    return SqlDbType.Binary;

                case "Bit":
                    return SqlDbType.Bit;
                case "Char":
                    return SqlDbType.Char;

                case "Date":
                    return SqlDbType.Date;

                case "DateTime":
                    return SqlDbType.DateTime;

                case "DateTime2":
                    return SqlDbType.DateTime2;

                case "DateTimeOffset":
                    return SqlDbType.DateTimeOffset;

                case "Decimal":
                    return SqlDbType.Decimal;

                case "Float":
                    return SqlDbType.Float;

                case "Image":
                    return SqlDbType.Image;

                case "Int":
                    return SqlDbType.Int;

                case "Money":
                    return SqlDbType.Money;

                case "NChar":
                    return SqlDbType.NChar;

                case "NText":
                    return SqlDbType.NText;

                case "NVarChar":
                    return SqlDbType.NVarChar;

                case "Real":
                    return SqlDbType.Real;

                case "SmallDateTime":
                    return SqlDbType.SmallDateTime;

                case "SmallInt":
                    return SqlDbType.SmallInt;

                case "SmallMoney":
                    return SqlDbType.SmallMoney;

                case "Structured":
                    return SqlDbType.Structured;

                case "Text":
                    return SqlDbType.Text;

                case "Time":
                    return SqlDbType.Time;

                case "Timestamp":
                    return SqlDbType.Timestamp;

                case "TinyInt":
                    return SqlDbType.TinyInt;

                case "Udt":
                    return SqlDbType.Udt;

                case "UniqueIdentifier":
                    return SqlDbType.UniqueIdentifier;

                case "VarBinary":
                    return SqlDbType.VarBinary;

                case "VarChar":
                    return SqlDbType.VarChar;

                case "Variant":
                    return SqlDbType.Variant;

                case "Xml":
                    return SqlDbType.Xml;

                default:
                    return 0;
            }

        }
    }
}
