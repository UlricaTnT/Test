var gulp = require('gulp'),
sass = require('gulp-ruby-sass'),
autoprefixer = require('gulp-autoprefixer'),
cssnano = require('gulp-cssnano'),
//jshint = require('gulp-jshint'),
uglify = require('gulp-uglify'),
imagemin = require('gulp-imagemin'),
rename = require('gulp-rename'),
concat = require('gulp-concat'),
notify = require('gulp-notify'),
cache = require('gulp-cache'),
livereload = require('gulp-livereload'),
del = require('del');
css = require('gulp-minify-css');

gulp.task('styles', function() {
    return gulp.src('src/css/*.css')
      .pipe(autoprefixer('last 2 version'))
    //   .pipe(gulp.dest('dist/assets/css'))
      .pipe(rename({suffix: '.min'}))
      .pipe(css())
      .pipe(gulp.dest('dist/assets/css'))
      .pipe(notify({ message: 'Styles task complete' }));
  });

gulp.task('scripts', function() {
    return gulp.src('src/js/*.js')
    //   .pipe(jshint('.jshintrc'))
    //   .pipe(jshint.reporter('default'))
      //.pipe(concat('vendor.js'))//合并js
      .pipe(gulp.dest('dist/assets/js'))
      .pipe(uglify())
      .pipe(rename({suffix: '.min'}))//名字变成script.min.js格式
      .pipe(gulp.dest('dist/assets/js'))
      .pipe(notify({ message: 'Scripts task complete' }));
  });


gulp.task('images', function() {
    return gulp.src('src/images/*')
    .pipe(cache(imagemin({ optimizationLevel: 5, progressive: true, interlaced: true })))
      .pipe(gulp.dest('dist/assets/images'))
      .pipe(notify({ message: 'Images task complete' }));
  });


gulp.task('clean', function() {
    return del(['dist/assets/css', 'dist/assets/js', 'dist/assets/images']);
});


gulp.task('default', ['clean'], function() {
    gulp.start('styles', 'scripts', 'images');
});


gulp.task('watch', function() {
    
      // Watch .scss files
      gulp.watch('src/css/*.css', ['styles']);
    
      // Watch .js files
      gulp.watch('src/js/*.js', ['scripts']);
    
      // Watch image files
      gulp.watch('src/images/*', ['images']);



      // Create LiveReload server
      livereload.listen();
  
      // Watch any files in dist/, reload on change
      gulp.watch(['dist/**']).on('change', livereload.changed);
    
});